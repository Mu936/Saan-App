import { Alert, AlertDescription } from "@/components/ui/alert";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Shield, Users, AlertTriangle, Briefcase } from "lucide-react";
import { useNavigate } from "react-router-dom";

const AdminSetup = () => {
  const navigate = useNavigate();

  return (
    <div className="max-w-2xl mx-auto p-6 space-y-6">
      <Card className="p-6 shadow-soft">
        <div className="text-center mb-6">
          <Shield className="w-12 h-12 text-rust-500 mx-auto mb-3" />
          <h2 className="text-2xl font-bold text-brown-500">
            SAAN Admin Setup
          </h2>
          <p className="text-brown-400 mt-2">
            Create your admin account to manage the platform
          </p>
        </div>

        <Alert className="mb-6 border-rust-200 bg-rust-50">
          <Shield className="h-4 w-4 text-rust-600" />
          <AlertDescription className="text-rust-800">
            <strong>Admin Credentials:</strong>
            <br />
            <code className="bg-rust-100 px-2 py-1 rounded">
              Email: admin@saan.app
            </code>
            <br />
            <code className="bg-rust-100 px-2 py-1 rounded">
              Password: admin
            </code>
          </AlertDescription>
        </Alert>

        <div className="space-y-4 mb-6">
          <h3 className="font-semibold text-brown-500">
            As Admin, you will be able to:
          </h3>

          <div className="grid grid-cols-1 gap-3">
            <div className="flex items-center space-x-3 p-3 bg-red-50 rounded-lg">
              <AlertTriangle className="w-5 h-5 text-red-500" />
              <div>
                <p className="font-medium text-red-700">
                  Monitor Emergency Alerts
                </p>
                <p className="text-red-600 text-sm">
                  24/7 SOS response and coordination
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
              <Briefcase className="w-5 h-5 text-blue-500" />
              <div>
                <p className="font-medium text-blue-700">
                  Moderate Job Postings
                </p>
                <p className="text-blue-600 text-sm">
                  Review and approve job opportunities
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
              <Users className="w-5 h-5 text-green-500" />
              <div>
                <p className="font-medium text-green-700">Manage Users</p>
                <p className="text-green-600 text-sm">
                  User verification and platform management
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <Button
            onClick={() => navigate("/signup")}
            className="w-full bg-rust-500 hover:bg-rust-600 text-white py-3"
          >
            Create Admin Account
          </Button>

          <Button
            onClick={() => navigate("/login")}
            variant="outline"
            className="w-full border-rust-200 text-rust-600"
          >
            Login as Admin
          </Button>
        </div>

        <div className="mt-6 p-4 bg-sand-50 rounded-lg">
          <h4 className="font-medium text-brown-500 mb-2">For Alumni Users:</h4>
          <p className="text-brown-400 text-sm">
            Regular users can create accounts with any email address to access
            networking, job opportunities, e-learning, and emergency features.
          </p>
        </div>
      </Card>
    </div>
  );
};

export default AdminSetup;
