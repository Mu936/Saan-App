import { Home, MessageCircle, Briefcase, User } from "lucide-react";
import { useLocation, useNavigate } from "react-router-dom";

const BottomNavigation = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const navItems = [
    { icon: Home, label: "Home", path: "/home" },
    { icon: MessageCircle, label: "Chat", path: "/chat" },
    { icon: Briefcase, label: "Jobs", path: "/opportunities" },
    { icon: User, label: "Profile", path: "/profile" },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-sand-200 shadow-soft-lg">
      <div className="grid grid-cols-4">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path;
          const Icon = item.icon;

          return (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className={`flex flex-col items-center py-3 px-2 transition-colors ${
                isActive
                  ? "text-rust-500"
                  : "text-brown-300 hover:text-brown-400"
              }`}
            >
              <Icon
                className={`w-6 h-6 mb-1 ${isActive ? "text-rust-500" : ""}`}
              />
              <span
                className={`text-xs font-medium ${
                  isActive ? "text-rust-500" : "text-brown-400"
                }`}
              >
                {item.label}
              </span>
              {isActive && (
                <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-8 h-1 bg-rust-500 rounded-b-full" />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default BottomNavigation;
