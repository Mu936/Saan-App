import { Alert, AlertDescription } from "@/components/ui/alert";
import { Info } from "lucide-react";
import { isDevelopmentMode } from "@/lib/firebase";

const DevModeNotice = () => {
  if (!isDevelopmentMode) return null;

  return (
    <Alert className="mb-4 border-amber-200 bg-amber-50">
      <Info className="h-4 w-4 text-amber-600" />
      <AlertDescription className="text-amber-800">
        <strong>Demo Mode:</strong> You're using the app with demo data. To use
        real Firebase features, follow the setup instructions in{" "}
        <code className="bg-amber-100 px-1 rounded">FIREBASE_SETUP.md</code>
      </AlertDescription>
    </Alert>
  );
};

export default DevModeNotice;
