import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  AlertTriangle,
  MapPin,
  Clock,
  Phone,
  X,
  MessageCircle,
  Navigation,
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { isDevelopmentMode } from "@/lib/firebase";
import {
  collection,
  query,
  where,
  orderBy,
  onSnapshot,
  updateDoc,
  doc,
} from "firebase/firestore";
import { db } from "@/lib/firebase";
import { toast } from "sonner";

interface EmergencyAlert {
  id: string;
  userId: string;
  userName: string;
  userPhone?: string;
  location: string;
  message: string;
  timestamp: Date;
  coordinates?: { lat: number; lng: number };
  helpOffered: string[]; // Array of user IDs who offered help
  status: "active" | "resolved";
}

const EmergencyBroadcast = () => {
  const { user, userProfile } = useAuth();
  const [emergencyAlerts, setEmergencyAlerts] = useState<EmergencyAlert[]>([]);
  const [dismissedAlerts, setDismissedAlerts] = useState<Set<string>>(
    new Set(),
  );

  // Real-time Firebase listeners for emergency alerts
  useEffect(() => {
    if (isDevelopmentMode) {
      // In development mode, don't show any emergencies unless explicitly triggered
      return;
    }

    // Listen for active emergency alerts from Firebase
    const emergenciesQuery = query(
      collection(db, "emergencies"),
      where("status", "==", "active"),
      orderBy("timestamp", "desc"),
    );

    const unsubscribe = onSnapshot(
      emergenciesQuery,
      (snapshot) => {
        const alerts = snapshot.docs.map((doc) => {
          const data = doc.data();
          return {
            id: doc.id,
            ...data,
            timestamp: data.timestamp?.toDate() || new Date(),
            helpOffered: data.helpOffered || [],
          } as EmergencyAlert;
        });

        console.log("Real emergency alerts:", alerts);
        setEmergencyAlerts(alerts);
      },
      (error) => {
        console.error("Error listening to emergencies:", error);
      },
    );

    return () => unsubscribe();
  }, []);

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffMinutes = Math.floor(
      (now.getTime() - date.getTime()) / (1000 * 60),
    );

    if (diffMinutes < 1) return "Just now";
    if (diffMinutes < 60) return `${diffMinutes} min ago`;
    return `${Math.floor(diffMinutes / 60)} hour ago`;
  };

  const handleOfferHelp = async (alertId: string) => {
    if (!user) return;

    try {
      const alert = emergencyAlerts.find((a) => a.id === alertId);
      if (!alert) return;

      const isCurrentlyOffering = alert.helpOffered.includes(user.uid);
      const newHelpOffered = isCurrentlyOffering
        ? alert.helpOffered.filter((id) => id !== user.uid)
        : [...alert.helpOffered, user.uid];

      if (!isDevelopmentMode) {
        // Update Firebase
        const emergencyRef = doc(db, "emergencies", alertId);
        await updateDoc(emergencyRef, {
          helpOffered: newHelpOffered,
        });
      }

      // Update local state for immediate feedback
      setEmergencyAlerts((alerts) =>
        alerts.map((a) =>
          a.id === alertId ? { ...a, helpOffered: newHelpOffered } : a,
        ),
      );

      if (!isCurrentlyOffering) {
        toast.success(
          `You've offered to help ${alert.userName}. They will be notified of your assistance.`,
        );
      } else {
        toast.info("Help offer withdrawn.");
      }
    } catch (error) {
      console.error("Error offering help:", error);
      toast.error("Failed to offer help. Please try again.");
    }
  };

  const handleContactUser = (alert: EmergencyAlert) => {
    if (alert.userPhone) {
      window.open(`tel:${alert.userPhone}`, "_blank");
    } else {
      toast.info(`Contact ${alert.userName} through the chat system.`);
    }
  };

  const handleViewLocation = (alert: EmergencyAlert) => {
    if (alert.coordinates) {
      const { lat, lng } = alert.coordinates;
      const googleMapsUrl = `https://www.google.com/maps?q=${lat},${lng}`;
      window.open(googleMapsUrl, "_blank");
    } else {
      toast.info(`Location: ${alert.location}`);
    }
  };

  const handleDismissAlert = (alertId: string) => {
    setDismissedAlerts((prev) => new Set([...prev, alertId]));
  };

  const activeAlerts = emergencyAlerts.filter(
    (alert) => alert.status === "active" && !dismissedAlerts.has(alert.id),
  );

  if (activeAlerts.length === 0) return null;

  return (
    <div className="fixed top-4 left-4 right-4 z-50 space-y-3">
      {activeAlerts.map((alert) => (
        <Card
          key={alert.id}
          className="bg-red-50 border-red-200 border-l-4 border-l-red-500 shadow-lg animate-pulse"
        >
          <div className="p-4">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-red-500" />
                <Badge variant="destructive" className="animate-pulse">
                  EMERGENCY ALERT
                </Badge>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => handleDismissAlert(alert.id)}
                className="h-6 w-6 text-red-400 hover:text-red-600"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>

            <div className="space-y-2 mb-4">
              <h3 className="font-semibold text-red-800">
                {alert.userName} needs help!
              </h3>

              <div className="flex items-center text-red-700 text-sm">
                <MapPin className="w-4 h-4 mr-1" />
                {alert.location}
              </div>

              <div className="flex items-center text-red-700 text-sm">
                <Clock className="w-4 h-4 mr-1" />
                {formatTimeAgo(alert.timestamp)}
              </div>

              <div className="bg-white p-3 rounded-lg border border-red-200">
                <p className="text-red-800 text-sm font-medium">
                  "{alert.message}"
                </p>
              </div>

              {alert.helpOffered.length > 0 && (
                <div className="text-green-700 text-sm">
                  🤝 {alert.helpOffered.length} people offered to help
                </div>
              )}
            </div>

            <div className="flex flex-wrap gap-2">
              <Button
                size="sm"
                onClick={() => handleOfferHelp(alert.id)}
                className={
                  alert.helpOffered.includes(user?.uid || "")
                    ? "bg-green-500 hover:bg-green-600"
                    : "bg-amber-500 hover:bg-amber-600"
                }
              >
                {alert.helpOffered.includes(user?.uid || "") ? (
                  <>✓ Help Offered</>
                ) : (
                  <>🤝 Offer Help</>
                )}
              </Button>

              <Button
                size="sm"
                variant="outline"
                onClick={() => handleContactUser(alert)}
                className="border-red-200 text-red-700 hover:bg-red-50"
              >
                <Phone className="w-4 h-4 mr-1" />
                Contact
              </Button>

              <Button
                size="sm"
                variant="outline"
                onClick={() => handleViewLocation(alert)}
                className="border-red-200 text-red-700 hover:bg-red-50"
              >
                <Navigation className="w-4 h-4 mr-1" />
                Location
              </Button>

              <Button
                size="sm"
                variant="outline"
                className="border-red-200 text-red-700 hover:bg-red-50"
              >
                <MessageCircle className="w-4 h-4 mr-1" />
                Chat
              </Button>
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
};

export default EmergencyBroadcast;
