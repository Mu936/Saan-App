import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Plus, MessageCircle } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { chatService } from "@/lib/firestore";
import { demoChatService } from "@/lib/demoChatService";
import { isDevelopmentMode } from "@/lib/firebase";
import { toast } from "sonner";

interface User {
  id: string;
  displayName: string;
  email: string;
  photoURL?: string;
}

interface UserSelectorProps {
  users: User[];
  onChatCreated: () => void;
}

const UserSelector = ({ users, onChatCreated }: UserSelectorProps) => {
  const { user } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const [creating, setCreating] = useState<string | null>(null);

  const createChatWithUser = async (otherUser: User) => {
    if (!user) {
      console.error("No user logged in");
      toast.error("You need to be logged in to create a chat");
      return;
    }

    console.log("Creating chat between:", user.uid, "and", otherUser.id);
    setCreating(otherUser.id);
    try {
      let chatId: string;

      if (isDevelopmentMode) {
        // Use demo service in development
        chatId = await demoChatService.createChat(
          [user.uid, otherUser.id],
          [user.displayName || "You", otherUser.displayName],
          false,
        );

        console.log("Demo chat created, sending welcome message...");
        // Send a welcome message from the other user (more realistic)
        await demoChatService.sendMessage(
          chatId,
          otherUser.id,
          otherUser.displayName,
          "Hi! I saw your profile on SAAN. Would love to connect and discuss opportunities! 😊",
        );
      } else {
        // Use real Firebase service
        chatId = await chatService.createChat(
          [user.uid, otherUser.id],
          [user.displayName || "You", otherUser.displayName],
          false,
        );

        console.log("Real chat created, sending welcome message...");
        // Send a welcome message
        await chatService.sendMessage(
          chatId,
          user.uid,
          user.displayName || "You",
          "Hi! I'd love to connect and discuss opportunities! 😊",
        );
      }

      toast.success(`Chat started with ${otherUser.displayName}`);
      setIsOpen(false);
      onChatCreated();
    } catch (error) {
      console.error("Detailed error creating chat:", error);

      // More specific error messages
      if (error instanceof Error) {
        if (error.message.includes("permission")) {
          toast.error("Permission denied. Check your Firebase security rules.");
        } else if (error.message.includes("network")) {
          toast.error("Network error. Please check your connection.");
        } else {
          toast.error(`Failed to create chat: ${error.message}`);
        }
      } else {
        toast.error("Failed to create chat. Please try again.");
      }
    } finally {
      setCreating(null);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="icon" className="text-brown-400">
          <Plus className="w-6 h-6" />
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Start a new chat</DialogTitle>
        </DialogHeader>
        <div className="space-y-3 max-h-96 overflow-y-auto">
          {users.length === 0 ? (
            <div className="text-center py-8">
              <MessageCircle className="w-12 h-12 text-brown-300 mx-auto mb-3" />
              <p className="text-brown-400">No other users available</p>
              <p className="text-brown-300 text-sm">
                Other users will appear here when they join
              </p>
            </div>
          ) : (
            users.map((otherUser) => (
              <Card
                key={otherUser.id}
                className="p-3 hover:shadow-soft transition-shadow cursor-pointer"
                onClick={() => createChatWithUser(otherUser)}
              >
                <div className="flex items-center space-x-3">
                  <Avatar className="w-10 h-10">
                    <AvatarImage src={otherUser.photoURL} />
                    <AvatarFallback className="bg-sand-200 text-brown-500">
                      {otherUser.displayName?.charAt(0) || "U"}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <h3 className="font-medium text-brown-500">
                      {otherUser.displayName}
                    </h3>
                    <p className="text-sm text-brown-400 truncate">
                      {otherUser.email}
                    </p>
                  </div>
                  {creating === otherUser.id && (
                    <div className="w-5 h-5 border-2 border-rust-500 border-t-transparent rounded-full animate-spin" />
                  )}
                </div>
              </Card>
            ))
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default UserSelector;
