import {
  createContext,
  useContext,
  useEffect,
  useState,
  ReactNode,
} from "react";

// Demo user profile type
interface DemoUserProfile {
  uid: string;
  email: string;
  displayName: string;
  bio?: string;
  location?: string;
  university?: string;
  graduationYear?: string;
  fieldOfStudy?: string;
  currentRole?: string;
  company?: string;
  photoURL?: string;
  connections: string[];
  skills: string[];
  interests: string[];
  createdAt: Date;
  updatedAt: Date;
}

// Demo user type
interface DemoUser {
  uid: string;
  email: string;
  displayName: string;
}

interface DemoAuthContextType {
  user: DemoUser | null;
  userProfile: DemoUserProfile | null;
  loading: boolean;
  signUp: (
    email: string,
    password: string,
    displayName: string,
  ) => Promise<void>;
  signIn: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  updateUserProfile: (profileData: Partial<DemoUserProfile>) => Promise<void>;
}

const DemoAuthContext = createContext<DemoAuthContextType | undefined>(
  undefined,
);

export const useDemoAuth = () => {
  const context = useContext(DemoAuthContext);
  if (context === undefined) {
    throw new Error("useDemoAuth must be used within a DemoAuthProvider");
  }
  return context;
};

interface DemoAuthProviderProps {
  children: ReactNode;
}

export const DemoAuthProvider = ({ children }: DemoAuthProviderProps) => {
  const [user, setUser] = useState<DemoUser | null>(null);
  const [userProfile, setUserProfile] = useState<DemoUserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check for existing demo session
    const savedUser = localStorage.getItem("demo-user");
    const savedProfile = localStorage.getItem("demo-profile");

    if (savedUser && savedProfile) {
      setUser(JSON.parse(savedUser));
      const profile = JSON.parse(savedProfile);
      // Convert date strings back to Date objects
      profile.createdAt = new Date(profile.createdAt);
      profile.updatedAt = new Date(profile.updatedAt);
      setUserProfile(profile);
    }

    setLoading(false);
  }, []);

  const signUp = async (
    email: string,
    password: string,
    displayName: string,
  ) => {
    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 1000));

    const demoUser: DemoUser = {
      uid: `demo-${Date.now()}`,
      email,
      displayName,
    };

    const demoProfile: DemoUserProfile = {
      uid: demoUser.uid,
      email: demoUser.email,
      displayName,
      connections: [],
      skills: [],
      interests: [],
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    // Save to localStorage
    localStorage.setItem("demo-user", JSON.stringify(demoUser));
    localStorage.setItem("demo-profile", JSON.stringify(demoProfile));

    setUser(demoUser);
    setUserProfile(demoProfile);
  };

  const signIn = async (email: string, password: string) => {
    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 1000));

    // For demo, create a session for any email/password
    const demoUser: DemoUser = {
      uid: `demo-${email.replace("@", "-").replace(".", "-")}`,
      email,
      displayName:
        email === "admin@saan.app" ? "SAAN Administrator" : email.split("@")[0],
    };

    const demoProfile: DemoUserProfile = {
      uid: demoUser.uid,
      email: demoUser.email,
      displayName: demoUser.displayName,
      bio: "African alumni connecting and building the future together",
      location: "Cape Town, South Africa",
      university: "University of Cape Town",
      graduationYear: "2020",
      fieldOfStudy: "Computer Science",
      currentRole: "Software Developer",
      company: "Tech Company",
      connections: ["demo-user-1", "demo-user-2", "demo-user-3"],
      skills: ["React", "TypeScript", "Node.js", "Python"],
      interests: [
        "Technology",
        "Mentorship",
        "African Development",
        "Innovation",
      ],
      createdAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), // 30 days ago
      updatedAt: new Date(),
    };

    // Save to localStorage
    localStorage.setItem("demo-user", JSON.stringify(demoUser));
    localStorage.setItem("demo-profile", JSON.stringify(demoProfile));

    setUser(demoUser);
    setUserProfile(demoProfile);
  };

  const logout = async () => {
    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 500));

    localStorage.removeItem("demo-user");
    localStorage.removeItem("demo-profile");
    setUser(null);
    setUserProfile(null);
  };

  const updateUserProfile = async (profileData: Partial<DemoUserProfile>) => {
    if (!user || !userProfile) throw new Error("No user logged in");

    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 500));

    const updatedProfile = {
      ...userProfile,
      ...profileData,
      updatedAt: new Date(),
    } as DemoUserProfile;

    localStorage.setItem("demo-profile", JSON.stringify(updatedProfile));
    setUserProfile(updatedProfile);
  };

  const value: DemoAuthContextType = {
    user,
    userProfile,
    loading,
    signUp,
    signIn,
    logout,
    updateUserProfile,
  };

  return (
    <DemoAuthContext.Provider value={value}>
      {children}
    </DemoAuthContext.Provider>
  );
};
