// Demo chat service for development mode

export interface DemoChat {
  id: string;
  participants: string[];
  participantNames: string[];
  isGroup: boolean;
  groupName?: string;
  lastMessage?: string;
  lastMessageTime?: Date;
  unreadCount: { [userId: string]: number };
  createdAt: Date;
}

export interface DemoChatMessage {
  id: string;
  chatId: string;
  senderId: string;
  senderName: string;
  message: string;
  timestamp: Date;
  type: "text" | "image" | "file";
}

// In-memory storage for demo
let demoChats: DemoChat[] = [
  {
    id: "demo-chat-1",
    participants: ["current-user", "demo-user-1"],
    participantNames: ["You", "Sarah Mbekeni"],
    isGroup: false,
    lastMessage: "Thanks for the mentorship session!",
    lastMessageTime: new Date(Date.now() - 15 * 60 * 1000),
    unreadCount: { "current-user": 1 },
    createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
  },
  {
    id: "demo-chat-2",
    participants: ["current-user", "demo-user-2", "demo-user-3"],
    participantNames: ["You", "David Okoye", "Amina Hassan"],
    isGroup: true,
    groupName: "Tech Alumni Group",
    lastMessage: "New job posting in Lagos",
    lastMessageTime: new Date(Date.now() - 2 * 60 * 60 * 1000),
    unreadCount: { "current-user": 0 },
    createdAt: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000),
  },
];

let demoMessages: DemoChatMessage[] = [
  {
    id: "msg-1",
    chatId: "demo-chat-1",
    senderId: "demo-user-1",
    senderName: "Sarah Mbekeni",
    message:
      "Thanks for the mentorship session! Really appreciate your insights on the tech industry in Cape Town.",
    timestamp: new Date(Date.now() - 15 * 60 * 1000),
    type: "text",
  },
  {
    id: "msg-2",
    chatId: "demo-chat-1",
    senderId: "demo-user-1",
    senderName: "Sarah Mbekeni",
    message: "Let's connect again next week if you're available?",
    timestamp: new Date(Date.now() - 10 * 60 * 1000),
    type: "text",
  },
  {
    id: "msg-3",
    chatId: "demo-chat-2",
    senderId: "demo-user-2",
    senderName: "David Okoye",
    message:
      "Hey everyone! I just posted a new Software Engineer position at my company in Lagos. Check it out in the opportunities section!",
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
    type: "text",
  },
];

export const demoChatService = {
  async getUserChats(userId: string): Promise<DemoChat[]> {
    await new Promise((resolve) => setTimeout(resolve, 300));
    return demoChats.filter(
      (chat) =>
        chat.participants.includes(userId) ||
        chat.participants.includes("current-user"),
    );
  },

  async createChat(
    participants: string[],
    participantNames: string[],
    isGroup = false,
    groupName?: string,
  ): Promise<string> {
    await new Promise((resolve) => setTimeout(resolve, 200));

    const newChat: DemoChat = {
      id: `demo-chat-${Date.now()}`,
      participants,
      participantNames,
      isGroup,
      groupName,
      unreadCount: {},
      createdAt: new Date(),
    };

    demoChats.unshift(newChat);
    return newChat.id;
  },

  async sendMessage(
    chatId: string,
    senderId: string,
    senderName: string,
    message: string,
  ): Promise<void> {
    await new Promise((resolve) => setTimeout(resolve, 100));

    const newMessage: DemoChatMessage = {
      id: `msg-${Date.now()}`,
      chatId,
      senderId,
      senderName,
      message,
      timestamp: new Date(),
      type: "text",
    };

    demoMessages.push(newMessage);

    // Update chat's last message
    const chat = demoChats.find((c) => c.id === chatId);
    if (chat) {
      chat.lastMessage = message;
      chat.lastMessageTime = new Date();
    }
  },

  subscribeToMessages(
    chatId: string,
    callback: (messages: DemoChatMessage[]) => void,
  ) {
    // Get messages for this chat
    const chatMessages = demoMessages.filter((msg) => msg.chatId === chatId);
    callback(chatMessages);

    // Return unsubscribe function
    return () => {};
  },
};
