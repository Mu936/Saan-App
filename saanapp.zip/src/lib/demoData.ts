// Demo data for development mode
export interface DemoOpportunity {
  id: string;
  title: string;
  company: string;
  location: string;
  type: "full-time" | "part-time" | "contract" | "internship" | "remote";
  salary: string;
  description: string;
  requirements: string[];
  benefits: string[];
  postedBy: string;
  postedAt: Date;
  applications: string[];
  isActive: boolean;
}

export interface DemoCourse {
  id: string;
  title: string;
  instructor: string;
  instructorId: string;
  description: string;
  duration: string;
  difficulty: "beginner" | "intermediate" | "advanced";
  category: string;
  rating: number;
  enrolledUsers: string[];
  modules: Array<{
    id: string;
    title: string;
    description: string;
    duration: number;
    order: number;
  }>;
  createdAt: Date;
  isActive: boolean;
}

export interface DemoUserProgress {
  id: string;
  userId: string;
  courseId: string;
  completedModules: string[];
  currentModule: string;
  progress: number;
  enrolledAt: Date;
  lastAccessed: Date;
  completedAt?: Date;
}

export const demoOpportunities: DemoOpportunity[] = [
  {
    id: "demo-job-1",
    title: "Software Engineer",
    company: "Tech For Africa",
    location: "Cape Town, SA",
    type: "full-time",
    salary: "R 50,000 - R 80,000",
    description:
      "Join our mission to build technology solutions for Africa. We're looking for passionate developers to help create impactful software.",
    requirements: ["React", "TypeScript", "Node.js", "3+ years experience"],
    benefits: [
      "Remote work",
      "Health insurance",
      "Learning budget",
      "Equity options",
    ],
    postedBy: "demo-recruiter",
    postedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), // 2 days ago
    applications: [],
    isActive: true,
  },
  {
    id: "demo-job-2",
    title: "Marketing Manager",
    company: "African Growth Fund",
    location: "Lagos, Nigeria",
    type: "remote",
    salary: "₦ 200,000 - ₦ 350,000",
    description:
      "Drive marketing strategy for African startups and scale-ups. Lead digital campaigns and brand development.",
    requirements: [
      "Digital Marketing",
      "Content Strategy",
      "Analytics",
      "5+ years experience",
    ],
    benefits: [
      "Full remote",
      "Flexible hours",
      "Professional development",
      "Travel opportunities",
    ],
    postedBy: "demo-recruiter",
    postedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), // 1 week ago
    applications: [],
    isActive: true,
  },
  {
    id: "demo-job-3",
    title: "Data Analyst",
    company: "Development Bank",
    location: "Nairobi, Kenya",
    type: "contract",
    salary: "KES 80,000 - KES 120,000",
    description:
      "Analyze development impact data across East Africa. Work with international development teams.",
    requirements: [
      "Python",
      "SQL",
      "Tableau",
      "Statistics",
      "2+ years experience",
    ],
    benefits: ["Contract flexibility", "Impact work", "International exposure"],
    postedBy: "demo-recruiter",
    postedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000), // 3 days ago
    applications: [],
    isActive: true,
  },
  {
    id: "demo-job-4",
    title: "Product Manager",
    company: "Fintech Startup",
    location: "Johannesburg, SA",
    type: "full-time",
    salary: "R 70,000 - R 120,000",
    description:
      "Lead product development for financial inclusion solutions across Africa.",
    requirements: [
      "Product Management",
      "Fintech experience",
      "Agile",
      "4+ years experience",
    ],
    benefits: ["Equity", "Health insurance", "Learning budget", "Impact work"],
    postedBy: "demo-recruiter",
    postedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000), // 1 day ago
    applications: [],
    isActive: true,
  },
];

export const demoCourses: DemoCourse[] = [
  {
    id: "demo-course-1",
    title: "Leadership in African Business",
    instructor: "Dr. Amina Hassan",
    instructorId: "demo-instructor-1",
    description:
      "Develop leadership skills specific to the African business context. Learn from successful African leaders and case studies.",
    duration: "6 weeks",
    difficulty: "intermediate",
    category: "Leadership",
    rating: 4.8,
    enrolledUsers: [],
    modules: [
      {
        id: "module-1",
        title: "African Business Landscape",
        description: "Understanding opportunities and challenges",
        duration: 45,
        order: 1,
      },
      {
        id: "module-2",
        title: "Cultural Intelligence",
        description: "Leading across diverse African cultures",
        duration: 60,
        order: 2,
      },
      {
        id: "module-3",
        title: "Strategic Thinking",
        description: "Developing strategic mindset for African markets",
        duration: 50,
        order: 3,
      },
    ],
    createdAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
    isActive: true,
  },
  {
    id: "demo-course-2",
    title: "Digital Marketing for Startups",
    instructor: "Marcus Osei",
    instructorId: "demo-instructor-2",
    description:
      "Learn digital marketing strategies tailored for African startups and emerging markets.",
    duration: "4 weeks",
    difficulty: "beginner",
    category: "Marketing",
    rating: 4.6,
    enrolledUsers: [],
    modules: [
      {
        id: "module-1",
        title: "Digital Marketing Fundamentals",
        description: "Basic concepts and strategies",
        duration: 40,
        order: 1,
      },
      {
        id: "module-2",
        title: "Social Media Marketing",
        description: "Leveraging social platforms",
        duration: 35,
        order: 2,
      },
    ],
    createdAt: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000),
    isActive: true,
  },
  {
    id: "demo-course-3",
    title: "Financial Planning & Investment",
    instructor: "Sarah Mthembu",
    instructorId: "demo-instructor-3",
    description:
      "Master personal and business financial planning with focus on African markets.",
    duration: "8 weeks",
    difficulty: "advanced",
    category: "Finance",
    rating: 4.9,
    enrolledUsers: [],
    modules: [
      {
        id: "module-1",
        title: "Financial Fundamentals",
        description: "Core financial concepts",
        duration: 60,
        order: 1,
      },
    ],
    createdAt: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000),
    isActive: true,
  },
];

// Demo services that mimic Firebase operations
export const demoOpportunitiesService = {
  async getAll() {
    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 500));
    return [...demoOpportunities];
  },

  async create(jobData: any) {
    await new Promise((resolve) => setTimeout(resolve, 300));
    const newJob: DemoOpportunity = {
      id: `demo-job-${Date.now()}`,
      ...jobData,
    };
    demoOpportunities.unshift(newJob); // Add to beginning of array
    return newJob.id;
  },

  async apply(opportunityId: string, userId: string) {
    await new Promise((resolve) => setTimeout(resolve, 300));
    const opportunity = demoOpportunities.find((o) => o.id === opportunityId);
    if (opportunity && !opportunity.applications.includes(userId)) {
      opportunity.applications.push(userId);
    }
  },

  subscribeToOpportunities(
    callback: (opportunities: DemoOpportunity[]) => void,
  ) {
    // Immediately call with data
    callback([...demoOpportunities]);

    // Return a no-op unsubscribe function
    return () => {};
  },
};

export const demoLearningService = {
  async getAllCourses() {
    await new Promise((resolve) => setTimeout(resolve, 400));
    return [...demoCourses];
  },

  async getUserProgress(userId: string): Promise<DemoUserProgress[]> {
    await new Promise((resolve) => setTimeout(resolve, 300));

    // Return some demo progress
    return [
      {
        id: "progress-1",
        userId,
        courseId: "demo-course-1",
        completedModules: ["module-1"],
        currentModule: "module-2",
        progress: 35,
        enrolledAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
        lastAccessed: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
      },
    ];
  },

  async enrollInCourse(userId: string, courseId: string) {
    await new Promise((resolve) => setTimeout(resolve, 300));
    const course = demoCourses.find((c) => c.id === courseId);
    if (course && !course.enrolledUsers.includes(userId)) {
      course.enrolledUsers.push(userId);
    }
    return `progress-${Date.now()}`;
  },
};

export const demoAnalyticsService = {
  async getUserStats(userId: string) {
    await new Promise((resolve) => setTimeout(resolve, 200));
    return {
      connections: 47,
      opportunities: demoOpportunities.length,
      events: 8,
    };
  },
};
