import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

// Firebase is now configured with real credentials
const isDevelopmentMode = false;

// Firebase configuration - your real SAAN project
const firebaseConfig = {
  apiKey: "AIzaSyA794TfmYroBA7WW_n3rUcP4cLoWkU_9NI",
  authDomain: "saan-b14ad.firebaseapp.com",
  projectId: "saan-b14ad",
  storageBucket: "saan-b14ad.firebasestorage.app",
  messagingSenderId: "457714403679",
  appId: "1:457714403679:web:0a2de834f246fa2a4fceea",
  measurementId: "G-S9R1WDD9KH",
};

// Initialize Firebase with your real project
const app = initializeApp(firebaseConfig);

// Initialize Firebase services
const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);

// Export Firebase services (will be null in development mode)
export { auth, db, storage, isDevelopmentMode };
export default app;
