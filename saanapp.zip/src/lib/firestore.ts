import {
  collection,
  doc,
  getDocs,
  getDoc,
  addDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  onSnapshot,
  Timestamp,
} from "firebase/firestore";
import { db } from "./firebase";

// Types
export interface Opportunity {
  id?: string;
  title: string;
  company: string;
  location: string;
  type: "full-time" | "part-time" | "contract" | "internship" | "remote";
  salary: string;
  description: string;
  requirements: string[];
  benefits: string[];
  postedBy: string; // User ID
  postedAt: Date;
  applications: string[]; // Array of user IDs
  isActive: boolean;
}

export interface ChatMessage {
  id?: string;
  chatId: string;
  senderId: string;
  senderName: string;
  senderAvatar?: string;
  message: string;
  timestamp: Date;
  type: "text" | "image" | "file";
  fileUrl?: string;
  fileName?: string;
}

export interface Chat {
  id?: string;
  participants: string[]; // Array of user IDs
  participantNames: string[];
  isGroup: boolean;
  groupName?: string;
  groupAvatar?: string;
  lastMessage?: string;
  lastMessageTime?: Date;
  unreadCount: { [userId: string]: number };
  createdAt: Date;
}

export interface Course {
  id?: string;
  title: string;
  instructor: string;
  instructorId: string;
  description: string;
  duration: string;
  difficulty: "beginner" | "intermediate" | "advanced";
  category: string;
  rating: number;
  enrolledUsers: string[]; // Array of user IDs
  modules: CourseModule[];
  createdAt: Date;
  isActive: boolean;
}

export interface CourseModule {
  id: string;
  title: string;
  description: string;
  videoUrl?: string;
  resources: string[];
  duration: number; // in minutes
  order: number;
}

export interface UserProgress {
  id?: string;
  userId: string;
  courseId: string;
  completedModules: string[];
  currentModule: string;
  progress: number; // percentage
  enrolledAt: Date;
  lastAccessed: Date;
  completedAt?: Date;
}

// Opportunities Service
export const opportunitiesService = {
  async getAll() {
    const q = query(
      collection(db, "opportunities"),
      where("isActive", "==", true),
      orderBy("postedAt", "desc"),
    );
    const snapshot = await getDocs(q);
    return snapshot.docs.map(
      (doc) => ({ id: doc.id, ...doc.data() }) as Opportunity,
    );
  },

  async getById(id: string) {
    const docRef = doc(db, "opportunities", id);
    const docSnap = await getDoc(docRef);
    return docSnap.exists()
      ? ({ id: docSnap.id, ...docSnap.data() } as Opportunity)
      : null;
  },

  async create(opportunity: Omit<Opportunity, "id">) {
    try {
      console.log("Creating opportunity:", opportunity);
      const docRef = await addDoc(collection(db, "opportunities"), {
        ...opportunity,
        postedAt: Timestamp.fromDate(opportunity.postedAt),
      });
      console.log("Opportunity created with ID:", docRef.id);
      return docRef.id;
    } catch (error) {
      console.error("Error creating opportunity:", error);
      if (error instanceof Error && error.message.includes("permission")) {
        throw new Error(
          "Permission denied. Please check your Firebase security rules for the 'opportunities' collection.",
        );
      }
      throw error;
    }
  },

  async apply(opportunityId: string, userId: string) {
    const opportunityRef = doc(db, "opportunities", opportunityId);
    const opportunity = await getDoc(opportunityRef);
    if (opportunity.exists()) {
      const currentApplications = opportunity.data().applications || [];
      if (!currentApplications.includes(userId)) {
        await updateDoc(opportunityRef, {
          applications: [...currentApplications, userId],
        });
      }
    }
  },

  subscribeToOpportunities(callback: (opportunities: Opportunity[]) => void) {
    const q = query(
      collection(db, "opportunities"),
      where("isActive", "==", true),
      orderBy("postedAt", "desc"),
      limit(50),
    );
    return onSnapshot(q, (snapshot) => {
      const opportunities = snapshot.docs.map(
        (doc) =>
          ({
            id: doc.id,
            ...doc.data(),
            postedAt: doc.data().postedAt.toDate(),
          }) as Opportunity,
      );
      callback(opportunities);
    });
  },
};

// Chat Service
export const chatService = {
  async getUserChats(userId: string) {
    const q = query(
      collection(db, "chats"),
      where("participants", "array-contains", userId),
      orderBy("lastMessageTime", "desc"),
    );
    const snapshot = await getDocs(q);
    return snapshot.docs.map((doc) => {
      const data = doc.data();
      return {
        id: doc.id,
        ...data,
        createdAt: data.createdAt?.toDate() || new Date(),
        lastMessageTime: data.lastMessageTime?.toDate(),
      } as Chat;
    });
  },

  async createChat(
    participants: string[],
    participantNames: string[],
    isGroup = false,
    groupName?: string,
  ) {
    try {
      console.log(
        "Creating chat with participants:",
        participants,
        participantNames,
      );

      // Check if a 1-on-1 chat between these users already exists
      if (!isGroup && participants.length === 2) {
        try {
          const existingChatQuery = query(
            collection(db, "chats"),
            where("participants", "array-contains", participants[0]),
            where("isGroup", "==", false),
          );
          const existingChats = await getDocs(existingChatQuery);

          for (const chatDoc of existingChats.docs) {
            const chatData = chatDoc.data();
            if (chatData.participants.includes(participants[1])) {
              console.log("Found existing chat:", chatDoc.id);
              return chatDoc.id; // Return existing chat ID
            }
          }
        } catch (error) {
          console.warn("Error checking for existing chats:", error);
          // Continue with creating new chat
        }
      }

      const chat: Omit<Chat, "id"> = {
        participants,
        participantNames,
        isGroup,
        groupName,
        unreadCount: {},
        createdAt: new Date(),
      };

      console.log("Creating new chat document:", chat);

      // Only include fields that are not undefined
      const chatDocument: any = {
        participants,
        participantNames,
        isGroup,
        unreadCount: {},
        createdAt: Timestamp.fromDate(chat.createdAt),
      };

      // Only add groupName if it's defined (for group chats)
      if (groupName !== undefined) {
        chatDocument.groupName = groupName;
      }

      const docRef = await addDoc(collection(db, "chats"), chatDocument);
      console.log("Chat created successfully with ID:", docRef.id);
      return docRef.id;
    } catch (error) {
      console.error("Error in createChat:", error);
      throw error;
    }
  },

  async sendMessage(
    chatId: string,
    senderId: string,
    senderName: string,
    message: string,
  ) {
    if (!chatId || !senderId || !senderName || !message) {
      throw new Error("Missing required fields for sending message");
    }

    const messageData: Omit<ChatMessage, "id"> = {
      chatId,
      senderId,
      senderName,
      message,
      timestamp: new Date(),
      type: "text",
    };

    await addDoc(collection(db, "messages"), {
      ...messageData,
      timestamp: Timestamp.fromDate(messageData.timestamp),
    });

    // Update last message in chat
    const chatRef = doc(db, "chats", chatId);
    await updateDoc(chatRef, {
      lastMessage: message,
      lastMessageTime: Timestamp.fromDate(new Date()),
    });
  },

  subscribeToMessages(
    chatId: string,
    callback: (messages: ChatMessage[]) => void,
  ) {
    const q = query(
      collection(db, "messages"),
      where("chatId", "==", chatId),
      orderBy("timestamp", "asc"),
    );
    return onSnapshot(q, (snapshot) => {
      const messages = snapshot.docs.map(
        (doc) =>
          ({
            id: doc.id,
            ...doc.data(),
            timestamp: doc.data().timestamp.toDate(),
          }) as ChatMessage,
      );
      callback(messages);
    });
  },

  subscribeToUserChats(userId: string, callback: (chats: Chat[]) => void) {
    const q = query(
      collection(db, "chats"),
      where("participants", "array-contains", userId),
      orderBy("lastMessageTime", "desc"),
    );
    return onSnapshot(q, (snapshot) => {
      const chats = snapshot.docs.map((doc) => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate() || new Date(),
          lastMessageTime: data.lastMessageTime?.toDate(),
        } as Chat;
      });
      callback(chats);
    });
  },

  async getAllUsers() {
    try {
      console.log("Fetching all users from Firebase...");
      const q = query(collection(db, "users"));
      const snapshot = await getDocs(q);
      const users = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      console.log("Found users:", users);
      return users;
    } catch (error) {
      console.error("Error fetching users:", error);
      if (error instanceof Error && error.message.includes("permission")) {
        console.error(
          "Permission denied. You may need to update your Firestore security rules.",
        );
        console.error("Suggested temporary rules for testing:");
        console.error(`
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    allow read, write: if request.auth != null;
  }
}
        `);
      }
      throw error;
    }
  },
};

// Learning Service
export const learningService = {
  async getAllCourses() {
    const q = query(
      collection(db, "courses"),
      where("isActive", "==", true),
      orderBy("createdAt", "desc"),
    );
    const snapshot = await getDocs(q);
    return snapshot.docs.map(
      (doc) => ({ id: doc.id, ...doc.data() }) as Course,
    );
  },

  async getUserProgress(userId: string) {
    const q = query(
      collection(db, "userProgress"),
      where("userId", "==", userId),
    );
    const snapshot = await getDocs(q);
    return snapshot.docs.map(
      (doc) => ({ id: doc.id, ...doc.data() }) as UserProgress,
    );
  },

  async enrollInCourse(userId: string, courseId: string) {
    const progressData: Omit<UserProgress, "id"> = {
      userId,
      courseId,
      completedModules: [],
      currentModule: "",
      progress: 0,
      enrolledAt: new Date(),
      lastAccessed: new Date(),
    };
    const docRef = await addDoc(collection(db, "userProgress"), progressData);

    // Update course enrolled users
    const courseRef = doc(db, "courses", courseId);
    const course = await getDoc(courseRef);
    if (course.exists()) {
      const currentEnrolled = course.data().enrolledUsers || [];
      if (!currentEnrolled.includes(userId)) {
        await updateDoc(courseRef, {
          enrolledUsers: [...currentEnrolled, userId],
        });
      }
    }

    return docRef.id;
  },

  async updateProgress(
    progressId: string,
    completedModules: string[],
    progress: number,
  ) {
    const progressRef = doc(db, "userProgress", progressId);
    await updateDoc(progressRef, {
      completedModules,
      progress,
      lastAccessed: Timestamp.fromDate(new Date()),
      ...(progress === 100 && { completedAt: Timestamp.fromDate(new Date()) }),
    });
  },
};

// Analytics and Stats
export const analyticsService = {
  async getUserStats(userId: string) {
    // Get user's connections count
    const userDoc = await getDoc(doc(db, "users", userId));
    const connections = userDoc.exists()
      ? userDoc.data().connections?.length || 0
      : 0;

    // Get opportunities count (could be filtered by location/preferences)
    const opportunitiesSnapshot = await getDocs(
      query(collection(db, "opportunities"), where("isActive", "==", true)),
    );
    const opportunities = opportunitiesSnapshot.size;

    // Get upcoming events (you'd need to create an events collection)
    const events = 0; // Placeholder

    return {
      connections,
      opportunities,
      events,
    };
  },
};
