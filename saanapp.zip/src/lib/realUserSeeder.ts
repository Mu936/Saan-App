import { collection, doc, setDoc, getDocs } from "firebase/firestore";
import { db } from "./firebase";

export const checkAndSeedRealUsers = async () => {
  try {
    // Check if there are any users in the database
    const usersQuery = collection(db, "users");
    const usersSnapshot = await getDocs(usersQuery);

    console.log(`Found ${usersSnapshot.size} users in Firebase`);

    if (usersSnapshot.size < 2) {
      console.log(
        "Not enough users for chat. Consider registering more users or check if users are being saved properly.",
      );
    }

    return usersSnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }));
  } catch (error) {
    console.error("Error checking users:", error);

    if (error instanceof Error && error.message.includes("permission")) {
      console.error(
        "❌ PERMISSION DENIED: Your Firestore security rules are blocking user access.",
      );
      console.error(
        "🔧 Quick Fix: Go to Firebase Console > Firestore > Rules and use these temporary rules:",
      );
      console.error(`
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    allow read, write: if request.auth != null;
  }
}
      `);
      console.error(
        "⚠️  These rules are for testing only. Use proper rules in production!",
      );
    }

    throw error;
  }
};
