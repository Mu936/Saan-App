import { collection, addDoc, doc, setDoc } from "firebase/firestore";
import { db } from "./firebase";

export const seedDemoData = async () => {
  try {
    // Seed demo opportunities
    const opportunities = [
      {
        title: "Software Engineer",
        company: "Tech For Africa",
        location: "Cape Town, SA",
        type: "full-time",
        salary: "R 50,000 - R 80,000",
        description:
          "Join our mission to build technology solutions for Africa",
        requirements: ["React", "TypeScript", "Node.js"],
        benefits: ["Remote work", "Health insurance", "Learning budget"],
        postedBy: "demo-user",
        postedAt: new Date(),
        applications: [],
        isActive: true,
      },
      {
        title: "Marketing Manager",
        company: "African Growth Fund",
        location: "Lagos, Nigeria",
        type: "remote",
        salary: "₦ 200,000 - ₦ 350,000",
        description: "Drive marketing strategy for African startups",
        requirements: ["Digital Marketing", "Content Strategy", "Analytics"],
        benefits: [
          "Equity options",
          "Flexible hours",
          "Professional development",
        ],
        postedBy: "demo-user",
        postedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), // 1 week ago
        applications: [],
        isActive: true,
      },
      {
        title: "Data Analyst",
        company: "Development Bank",
        location: "Nairobi, Kenya",
        type: "contract",
        salary: "KES 80,000 - KES 120,000",
        description: "Analyze development impact data across East Africa",
        requirements: ["Python", "SQL", "Tableau", "Statistics"],
        benefits: [
          "Contract flexibility",
          "Impact work",
          "Travel opportunities",
        ],
        postedBy: "demo-user",
        postedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000), // 3 days ago
        applications: [],
        isActive: true,
      },
    ];

    for (const opportunity of opportunities) {
      await addDoc(collection(db, "opportunities"), opportunity);
    }

    // Seed demo courses
    const courses = [
      {
        title: "Leadership in African Business",
        instructor: "Dr. Amina Hassan",
        instructorId: "demo-instructor-1",
        description:
          "Develop leadership skills specific to the African business context",
        duration: "6 weeks",
        difficulty: "intermediate",
        category: "Leadership",
        rating: 4.8,
        enrolledUsers: [],
        modules: [
          {
            id: "module-1",
            title: "African Business Landscape",
            description:
              "Understanding the unique opportunities and challenges",
            duration: 45,
            order: 1,
            resources: [],
          },
          {
            id: "module-2",
            title: "Cultural Intelligence",
            description: "Leading across diverse African cultures",
            duration: 60,
            order: 2,
            resources: [],
          },
        ],
        createdAt: new Date(),
        isActive: true,
      },
      {
        title: "Digital Marketing for Startups",
        instructor: "Marcus Osei",
        instructorId: "demo-instructor-2",
        description: "Learn digital marketing strategies for African startups",
        duration: "4 weeks",
        difficulty: "beginner",
        category: "Marketing",
        rating: 4.6,
        enrolledUsers: [],
        modules: [
          {
            id: "module-1",
            title: "Digital Marketing Fundamentals",
            description: "Basic concepts and strategies",
            duration: 40,
            order: 1,
            resources: [],
          },
        ],
        createdAt: new Date(),
        isActive: true,
      },
    ];

    for (const course of courses) {
      await addDoc(collection(db, "courses"), course);
    }

    // Seed demo chat
    const demoChat = {
      participants: ["demo-user-1", "demo-user-2"],
      participantNames: ["Sarah Mbekeni", "Current User"],
      isGroup: false,
      lastMessage: "Thanks for the mentorship session!",
      lastMessageTime: new Date(),
      unreadCount: { "current-user": 1 },
      createdAt: new Date(),
    };

    await addDoc(collection(db, "chats"), demoChat);

    console.log("Demo data seeded successfully!");
  } catch (error) {
    console.error("Error seeding demo data:", error);
  }
};
