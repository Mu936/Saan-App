import { collection, doc, setDoc, getDoc } from "firebase/firestore";
import { db } from "./firebase";

export const seedDemoUsers = async () => {
  const demoUsers = [
    {
      id: "demo-user-1",
      displayName: "Sarah Mbekeni",
      email: "sarah@example.com",
      photoURL: "",
      university: "University of Cape Town",
      graduationYear: 2020,
      field: "Computer Science",
      location: "Cape Town, South Africa",
      skills: ["React", "Node.js", "Python"],
      interests: ["Tech", "Mentorship", "Entrepreneurship"],
      connections: [],
      createdAt: new Date(),
    },
    {
      id: "demo-user-2",
      displayName: "David Okoye",
      email: "david@example.com",
      photoURL: "",
      university: "University of Lagos",
      graduationYear: 2019,
      field: "Software Engineering",
      location: "Lagos, Nigeria",
      skills: ["JavaScript", "React Native", "MongoDB"],
      interests: ["Mobile Development", "Fintech", "AI"],
      connections: [],
      createdAt: new Date(),
    },
    {
      id: "demo-user-3",
      displayName: "Amina Hassan",
      email: "amina@example.com",
      photoURL: "",
      university: "University of Nairobi",
      graduationYear: 2021,
      field: "Data Science",
      location: "Nairobi, Kenya",
      skills: ["Python", "Machine Learning", "SQL"],
      interests: ["Data Analytics", "Healthcare Tech", "Research"],
      connections: [],
      createdAt: new Date(),
    },
  ];

  try {
    for (const user of demoUsers) {
      const userRef = doc(db, "users", user.id);
      const userDoc = await getDoc(userRef);

      // Only create if user doesn't exist
      if (!userDoc.exists()) {
        await setDoc(userRef, user);
        console.log(`Demo user ${user.displayName} created`);
      }
    }
    console.log("Demo users seeded successfully");
  } catch (error) {
    console.error("Error seeding demo users:", error);
  }
};
