// User roles and permissions system for SAAN

export enum UserRole {
  ALUMNI = "alumni",
  EMPLOYER = "employer",
  ADMIN = "admin",
  SUPER_ADMIN = "super_admin",
}

export enum Permission {
  // Basic user permissions
  VIEW_OPPORTUNITIES = "view_opportunities",
  APPLY_TO_JOBS = "apply_to_jobs",
  USE_CHAT = "use_chat",
  ACCESS_LEARNING = "access_learning",
  USE_EMERGENCY_SOS = "use_emergency_sos",

  // Employer permissions
  POST_JOBS = "post_jobs",
  VIEW_APPLICATIONS = "view_applications",
  MANAGE_COMPANY_PROFILE = "manage_company_profile",

  // Admin permissions
  MODERATE_JOBS = "moderate_jobs",
  MONITOR_EMERGENCIES = "monitor_emergencies",
  MANAGE_USERS = "manage_users",
  VIEW_ANALYTICS = "view_analytics",
  MODERATE_CONTENT = "moderate_content",

  // Super admin permissions
  PLATFORM_CONFIG = "platform_config",
  MANAGE_ADMINS = "manage_admins",
  SYSTEM_ADMIN = "system_admin",
}

export const ROLE_PERMISSIONS: Record<UserRole, Permission[]> = {
  [UserRole.ALUMNI]: [
    Permission.VIEW_OPPORTUNITIES,
    Permission.APPLY_TO_JOBS,
    Permission.USE_CHAT,
    Permission.ACCESS_LEARNING,
    Permission.USE_EMERGENCY_SOS,
  ],

  [UserRole.EMPLOYER]: [
    Permission.VIEW_OPPORTUNITIES,
    Permission.POST_JOBS,
    Permission.VIEW_APPLICATIONS,
    Permission.MANAGE_COMPANY_PROFILE,
    Permission.USE_CHAT,
  ],

  [UserRole.ADMIN]: [
    // All alumni permissions
    ...ROLE_PERMISSIONS[UserRole.ALUMNI],
    // Plus admin permissions
    Permission.MODERATE_JOBS,
    Permission.MONITOR_EMERGENCIES,
    Permission.MANAGE_USERS,
    Permission.VIEW_ANALYTICS,
    Permission.MODERATE_CONTENT,
  ],

  [UserRole.SUPER_ADMIN]: [
    // All admin permissions
    ...ROLE_PERMISSIONS[UserRole.ADMIN],
    // Plus super admin permissions
    Permission.PLATFORM_CONFIG,
    Permission.MANAGE_ADMINS,
    Permission.SYSTEM_ADMIN,
  ],
};

export interface UserWithRole {
  uid: string;
  email: string;
  displayName: string;
  role: UserRole;
  permissions: Permission[];
  isVerified: boolean;
  createdAt: Date;
}

export class RoleManager {
  static hasPermission(user: UserWithRole, permission: Permission): boolean {
    return user.permissions.includes(permission);
  }

  static hasRole(user: UserWithRole, role: UserRole): boolean {
    return user.role === role;
  }

  static isAdmin(user: UserWithRole): boolean {
    return user.role === UserRole.ADMIN || user.role === UserRole.SUPER_ADMIN;
  }

  static canModerateJobs(user: UserWithRole): boolean {
    return this.hasPermission(user, Permission.MODERATE_JOBS);
  }

  static canMonitorEmergencies(user: UserWithRole): boolean {
    return this.hasPermission(user, Permission.MONITOR_EMERGENCIES);
  }

  static canPostJobs(user: UserWithRole): boolean {
    return this.hasPermission(user, Permission.POST_JOBS);
  }

  static assignRole(user: UserWithRole, newRole: UserRole): UserWithRole {
    return {
      ...user,
      role: newRole,
      permissions: ROLE_PERMISSIONS[newRole],
    };
  }
}

// Predefined admin accounts for initial setup
export const INITIAL_ADMINS = [
  "admin@saan.app",
  "emergency@saan.app",
  "moderator@saan.app",
];

export const isInitialAdmin = (email: string): boolean => {
  return INITIAL_ADMINS.includes(email.toLowerCase());
};

// Emergency response team configuration
export interface EmergencyResponder {
  id: string;
  name: string;
  phone: string;
  email: string;
  location: string;
  specialization: "medical" | "security" | "general";
  isActive: boolean;
}

export const EMERGENCY_CONTACTS = {
  // Regional emergency coordinators
  "south-africa": {
    name: "SAAN Emergency SA",
    phone: "+27-800-SAAN-SOS",
    email: "emergency-sa@saan.app",
  },
  nigeria: {
    name: "SAAN Emergency NG",
    phone: "+234-800-SAAN-SOS",
    email: "emergency-ng@saan.app",
  },
  kenya: {
    name: "SAAN Emergency KE",
    phone: "+254-800-SAAN-SOS",
    email: "emergency-ke@saan.app",
  },
  ghana: {
    name: "SAAN Emergency GH",
    phone: "+233-800-SAAN-SOS",
    email: "emergency-gh@saan.app",
  },
};
