import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  AlertTriangle,
  Briefcase,
  Users,
  MessageSquare,
  CheckCircle,
  XCircle,
  Eye,
  MapPin,
  Clock,
  Phone,
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";

interface PendingJob {
  id: string;
  title: string;
  company: string;
  location: string;
  type: string;
  postedBy: string;
  postedAt: Date;
  status: "pending" | "approved" | "rejected";
}

interface EmergencyAlert {
  id: string;
  userId: string;
  userName: string;
  location: string;
  timestamp: Date;
  status: "active" | "responded" | "resolved";
  message?: string;
  coordinates?: { lat: number; lng: number };
}

const AdminDashboard = () => {
  const { user, userProfile } = useAuth();
  const navigate = useNavigate();

  // Check if user is the admin
  const isAdmin = userProfile?.email === "admin@saan.app";

  const [pendingJobs, setPendingJobs] = useState<PendingJob[]>([
    {
      id: "job-1",
      title: "Senior Software Engineer",
      company: "TechCorp Africa",
      location: "Lagos, Nigeria",
      type: "Full-time",
      postedBy: "employer-123",
      postedAt: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
      status: "pending",
    },
    {
      id: "job-2",
      title: "Marketing Manager",
      company: "StartupXYZ",
      location: "Cape Town, SA",
      type: "Remote",
      postedBy: "employer-456",
      postedAt: new Date(Date.now() - 4 * 60 * 60 * 1000), // 4 hours ago
      status: "pending",
    },
  ]);

  const [emergencyAlerts, setEmergencyAlerts] = useState<EmergencyAlert[]>([
    {
      id: "alert-1",
      userId: "user-123",
      userName: "Sarah Mbekeni",
      location: "Johannesburg, SA",
      timestamp: new Date(Date.now() - 15 * 60 * 1000), // 15 minutes ago
      status: "active",
      message: "Medical emergency - need immediate assistance",
      coordinates: { lat: -26.2041, lng: 28.0473 },
    },
    {
      id: "alert-2",
      userId: "user-456",
      userName: "David Okoye",
      location: "Lagos, Nigeria",
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
      status: "responded",
      message: "Safety concern in current area",
      coordinates: { lat: 6.5244, lng: 3.3792 },
    },
  ]);

  useEffect(() => {
    if (!user) {
      navigate("/welcome");
      return;
    }

    if (!isAdmin) {
      navigate("/home");
      return;
    }
  }, [user, isAdmin, navigate]);

  const handleJobApproval = (jobId: string, action: "approve" | "reject") => {
    const job = pendingJobs.find((j) => j.id === jobId);

    // Update job status in state
    setPendingJobs(
      (jobs) =>
        jobs
          .map((job) =>
            job.id === jobId
              ? {
                  ...job,
                  status: action === "approve" ? "approved" : "rejected",
                }
              : job,
          )
          .filter((job) => job.status === "pending"), // Remove from pending list
    );

    // Show success message
    if (action === "approve") {
      toast.success(
        `✅ Job "${job?.title}" has been APPROVED and is now live!`,
      );
    } else {
      toast.error(`❌ Job "${job?.title}" has been REJECTED.`);
    }

    // In real app: update job status in Firebase
    console.log(`${action} job ${jobId}`);
  };

  const handleEmergencyResponse = (
    alertId: string,
    action: "respond" | "resolve",
  ) => {
    const alert_user = emergencyAlerts.find((a) => a.id === alertId);

    // Update emergency status in state
    setEmergencyAlerts((alerts) =>
      alerts.map((alert) =>
        alert.id === alertId
          ? {
              ...alert,
              status: action === "respond" ? "responded" : "resolved",
            }
          : alert,
      ),
    );

    if (action === "respond") {
      toast.success(
        `🚨 Emergency response activated for ${alert_user?.userName}`,
      );
    } else {
      toast.success(`✅ Emergency resolved for ${alert_user?.userName}`);
    }

    // In real app: update emergency status, notify responders
    console.log(`${action} emergency ${alertId}`);
  };

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffMinutes = Math.floor(
      (now.getTime() - date.getTime()) / (1000 * 60),
    );

    if (diffMinutes < 1) return "Just now";
    if (diffMinutes < 60) return `${diffMinutes} min ago`;
    if (diffMinutes < 1440) return `${Math.floor(diffMinutes / 60)} hour ago`;
    return `${Math.floor(diffMinutes / 1440)} day ago`;
  };

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-beige-50 flex items-center justify-center">
        <Card className="p-8 text-center">
          <AlertTriangle className="w-12 h-12 text-amber-500 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-brown-500 mb-2">
            Access Denied
          </h2>
          <p className="text-brown-400">
            You don't have admin permissions to access this page.
          </p>
          <Button onClick={() => navigate("/home")} className="mt-4">
            Go to Dashboard
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-beige-50">
      {/* Header */}
      <div className="bg-white shadow-soft">
        <div className="px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-brown-500">SAAN Admin</h1>
              <p className="text-brown-400">Platform Management Dashboard</p>
            </div>
            <Badge variant="secondary" className="bg-rust-100 text-rust-700">
              Administrator
            </Badge>
          </div>
        </div>
      </div>

      <div className="px-4 py-6">
        {/* Stats Overview */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <Card className="p-4 text-center shadow-soft">
            <div className="text-2xl font-bold text-rust-500">
              {pendingJobs.length}
            </div>
            <div className="text-sm text-brown-400">Pending Jobs</div>
          </Card>
          <Card className="p-4 text-center shadow-soft">
            <div className="text-2xl font-bold text-red-500">
              {emergencyAlerts.filter((a) => a.status === "active").length}
            </div>
            <div className="text-sm text-brown-400">Active Alerts</div>
          </Card>
          <Card className="p-4 text-center shadow-soft">
            <div className="text-2xl font-bold text-olive-500">1,247</div>
            <div className="text-sm text-brown-400">Total Users</div>
          </Card>
          <Card className="p-4 text-center shadow-soft">
            <div className="text-2xl font-bold text-sand-600">89</div>
            <div className="text-sm text-brown-400">Active Jobs</div>
          </Card>
        </div>

        {/* Main Admin Tabs */}
        <Tabs defaultValue="emergencies" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger
              value="emergencies"
              className="flex items-center gap-2"
            >
              <AlertTriangle className="w-4 h-4" />
              Emergency Alerts
            </TabsTrigger>
            <TabsTrigger value="jobs" className="flex items-center gap-2">
              <Briefcase className="w-4 h-4" />
              Job Moderation
            </TabsTrigger>
            <TabsTrigger value="users" className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              User Management
            </TabsTrigger>
          </TabsList>

          {/* Emergency Alerts Tab */}
          <TabsContent value="emergencies">
            <Card className="p-6 shadow-soft">
              <h3 className="text-lg font-semibold text-brown-500 mb-4">
                Emergency Monitoring Center
              </h3>

              {emergencyAlerts.filter((a) => a.status !== "resolved").length ===
              0 ? (
                <div className="text-center py-8">
                  <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-3" />
                  <p className="text-brown-400">No active emergency alerts</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {emergencyAlerts
                    .filter((a) => a.status !== "resolved")
                    .map((alert) => (
                      <Card
                        key={alert.id}
                        className={`p-4 border-l-4 ${
                          alert.status === "active"
                            ? "border-l-red-500 bg-red-50"
                            : "border-l-amber-500 bg-amber-50"
                        }`}
                      >
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <h4 className="font-semibold text-brown-500">
                                {alert.userName}
                              </h4>
                              <Badge
                                variant={
                                  alert.status === "active"
                                    ? "destructive"
                                    : "default"
                                }
                              >
                                {alert.status.toUpperCase()}
                              </Badge>
                            </div>
                            <div className="flex items-center text-brown-400 text-sm mb-1">
                              <MapPin className="w-4 h-4 mr-1" />
                              {alert.location}
                            </div>
                            <div className="flex items-center text-brown-400 text-sm">
                              <Clock className="w-4 h-4 mr-1" />
                              {formatTimeAgo(alert.timestamp)}
                            </div>
                          </div>
                        </div>

                        {alert.message && (
                          <p className="text-brown-500 mb-3 p-3 bg-white rounded-lg">
                            "{alert.message}"
                          </p>
                        )}

                        <div className="flex space-x-2">
                          {alert.status === "active" && (
                            <>
                              <Button
                                size="sm"
                                className="bg-amber-500 hover:bg-amber-600 text-white"
                                onClick={() =>
                                  handleEmergencyResponse(alert.id, "respond")
                                }
                              >
                                <Phone className="w-4 h-4 mr-2" />
                                Respond
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() =>
                                  handleEmergencyResponse(alert.id, "resolve")
                                }
                              >
                                Mark Resolved
                              </Button>
                            </>
                          )}

                          {alert.status === "responded" && (
                            <Button
                              size="sm"
                              className="bg-green-500 hover:bg-green-600 text-white"
                              onClick={() =>
                                handleEmergencyResponse(alert.id, "resolve")
                              }
                            >
                              <CheckCircle className="w-4 h-4 mr-2" />
                              Mark Resolved
                            </Button>
                          )}

                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              if (alert.coordinates) {
                                const { lat, lng } = alert.coordinates;
                                const googleMapsUrl = `https://www.google.com/maps?q=${lat},${lng}`;
                                window.open(googleMapsUrl, "_blank");
                              } else {
                                toast.info(`📍 Location: ${alert.location}`);
                              }
                            }}
                          >
                            <MapPin className="w-4 h-4 mr-2" />
                            View Location
                          </Button>
                        </div>
                      </Card>
                    ))}
                </div>
              )}
            </Card>
          </TabsContent>

          {/* Job Moderation Tab */}
          <TabsContent value="jobs">
            <Card className="p-6 shadow-soft">
              <h3 className="text-lg font-semibold text-brown-500 mb-4">
                Job Posting Moderation
              </h3>

              {pendingJobs.length === 0 ? (
                <div className="text-center py-8">
                  <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-3" />
                  <p className="text-brown-400">No jobs pending review</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {pendingJobs.map((job) => (
                    <Card key={job.id} className="p-4 shadow-soft">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h4 className="font-semibold text-brown-500 mb-1">
                            {job.title}
                          </h4>
                          <p className="text-brown-400 mb-1">{job.company}</p>
                          <div className="flex items-center text-brown-400 text-sm">
                            <MapPin className="w-4 h-4 mr-1" />
                            {job.location} • {job.type}
                          </div>
                        </div>
                        <Badge
                          variant="outline"
                          className="border-amber-300 text-amber-700"
                        >
                          PENDING
                        </Badge>
                      </div>

                      <div className="text-brown-400 text-sm mb-4">
                        Posted {formatTimeAgo(job.postedAt)}
                      </div>

                      <div className="flex space-x-2">
                        <Button
                          size="sm"
                          className="bg-green-500 hover:bg-green-600 text-white"
                          onClick={() => handleJobApproval(job.id, "approve")}
                        >
                          <CheckCircle className="w-4 h-4 mr-2" />
                          Approve
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleJobApproval(job.id, "reject")}
                        >
                          <XCircle className="w-4 h-4 mr-2" />
                          Reject
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            toast.info(
                              `📋 Reviewing: ${job.title} at ${job.company}\n\nIn production, this would show full job details, requirements, salary, and company verification status.`,
                            );
                          }}
                        >
                          <Eye className="w-4 h-4 mr-2" />
                          Review Details
                        </Button>
                      </div>
                    </Card>
                  ))}
                </div>
              )}
            </Card>
          </TabsContent>

          {/* User Management Tab */}
          <TabsContent value="users">
            <Card className="p-6 shadow-soft">
              <h3 className="text-lg font-semibold text-brown-500 mb-4">
                User Management
              </h3>
              <div className="text-center py-8">
                <Users className="w-12 h-12 text-brown-300 mx-auto mb-3" />
                <p className="text-brown-400">User management features</p>
                <p className="text-brown-300 text-sm mt-2">
                  • View all registered users
                  <br />
                  • Verify alumni status
                  <br />
                  • Manage user roles and permissions
                  <br />• Monitor platform activity
                </p>
                <Button
                  onClick={() =>
                    toast.info(
                      "User management features will be available in the full production version.",
                    )
                  }
                  className="mt-4 bg-olive-500 hover:bg-olive-600"
                >
                  Coming Soon
                </Button>
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AdminDashboard;
