import BottomNavigation from "@/components/BottomNavigation";
import UserSelector from "@/components/UserSelector";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Plus, MessageCircle } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useAuth } from "@/hooks/useAuth";
import { isDevelopmentMode } from "@/lib/firebase";
import { chatService, type Chat } from "@/lib/firestore";
import { demoChatService, type DemoChat } from "@/lib/demoChatService";
import { checkAndSeedRealUsers } from "@/lib/realUserSeeder";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { collection, getDocs, query, where } from "firebase/firestore";
import { db } from "@/lib/firebase";

const Chat = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [chats, setChats] = useState<Chat[]>([]);
  const [allUsers, setAllUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    if (!user) {
      navigate("/welcome");
      return;
    }

    const loadData = async () => {
      try {
        if (isDevelopmentMode) {
          // Use demo service in development
          const userChats = await demoChatService.getUserChats(user.uid);
          setChats(userChats as any);
          console.log("Demo chats loaded:", userChats);

          // Add demo users for chat creation
          const demoUsers = [
            {
              id: "demo-user-1",
              displayName: "Sarah Mbekeni",
              email: "sarah@example.com",
              photoURL: "",
            },
            {
              id: "demo-user-2",
              displayName: "David Okoye",
              email: "david@example.com",
              photoURL: "",
            },
            {
              id: "demo-user-3",
              displayName: "Amina Hassan",
              email: "amina@example.com",
              photoURL: "",
            },
            {
              id: "demo-user-4",
              displayName: "Kwame Asante",
              email: "kwame@example.com",
              photoURL: "",
            },
          ];
          setAllUsers(demoUsers);
          console.log("Demo users loaded:", demoUsers);
          setLoading(false);
        } else {
          // Use real Firebase service with real-time subscriptions
          const unsubscribe = chatService.subscribeToUserChats(
            user.uid,
            (userChats) => {
              setChats(userChats);
              setLoading(false);
              console.log("Real-time chats updated:", userChats);
            },
          );

          // Load all real users from Firebase
          try {
            const users = await checkAndSeedRealUsers();
            const filteredUsers = users.filter((u) => u.id !== user.uid); // Exclude current user
            setAllUsers(filteredUsers);

            console.log("Real Firebase users loaded:", filteredUsers);

            if (filteredUsers.length === 0) {
              console.warn(
                "No other users found in Firebase. You need at least 2 registered users to test chat.",
              );
              toast.error(
                "No other users found. Register another account to test chat!",
              );
            }
          } catch (error) {
            console.error("Error loading real users:", error);
            if (
              error instanceof Error &&
              error.message.includes("permission")
            ) {
              toast.error(
                "Permission denied. Please update your Firebase security rules.",
              );
            } else {
              toast.error("Failed to load users from Firebase");
            }
          }

          // Return unsubscribe function to cleanup
          return unsubscribe;
        }
      } catch (error) {
        console.error("Error loading chats:", error);
        toast.error("Failed to load chats");
        setLoading(false);
      }
    };

    const unsubscribePromise = loadData();

    // Cleanup subscription on unmount
    return () => {
      if (unsubscribePromise && typeof unsubscribePromise.then === "function") {
        unsubscribePromise.then((unsubscribe) => {
          if (unsubscribe && typeof unsubscribe === "function") {
            unsubscribe();
          }
        });
      }
    };
  }, [user, navigate]);

  const filteredChats = chats.filter((chat) =>
    chat.isGroup
      ? chat.groupName?.toLowerCase().includes(searchTerm.toLowerCase())
      : chat.participantNames.some((name) =>
          name.toLowerCase().includes(searchTerm.toLowerCase()),
        ),
  );

  const handleChatClick = (chatId: string) => {
    navigate(`/chat/${chatId}`);
  };

  const createNewChat = async () => {
    if (!user) return;

    try {
      if (isDevelopmentMode) {
        // Use demo service in development
        if (allUsers.length === 0) {
          toast.error("No demo users available to chat with");
          return;
        }

        // Create a chat with a random demo user
        const randomUser =
          allUsers[Math.floor(Math.random() * allUsers.length)];
        const chatId = await demoChatService.createChat(
          [user.uid, randomUser.id],
          [user.displayName || "You", randomUser.displayName],
          false,
        );

        // Send a demo message
        await demoChatService.sendMessage(
          chatId,
          randomUser.id,
          randomUser.displayName,
          "Hi! I saw your profile on SAAN. Would love to connect and discuss opportunities! 😊",
        );

        // Reload chats
        const userChats = await demoChatService.getUserChats(user.uid);
        setChats(userChats as any);
        console.log("New demo chat created with:", randomUser.displayName);
        toast.success(`New chat created with ${randomUser.displayName}!`);
      } else {
        // Create real chat with another user
        if (allUsers.length === 0) {
          toast.error("No other users available to chat with");
          return;
        }

        // For now, create a chat with the first available user
        const otherUser = allUsers[0];
        const chatId = await chatService.createChat(
          [user.uid, otherUser.id],
          [user.displayName || "You", otherUser.displayName || "User"],
          false,
        );

        // Send a welcome message
        await chatService.sendMessage(
          chatId,
          user.uid,
          user.displayName || "You",
          "Hi! I'd love to connect and discuss opportunities! 😊",
        );

        // Reload chats
        const userChats = await chatService.getUserChats(user.uid);
        setChats(userChats);
        console.log("New real chat created");
        toast.success("New chat created!");
      }
    } catch (error) {
      console.error("Error creating chat:", error);
      toast.error("Failed to create chat");
    }
  };

  const formatTime = (date?: Date) => {
    if (!date) return "";
    const now = new Date();
    const diffMinutes = Math.floor(
      (now.getTime() - date.getTime()) / (1000 * 60),
    );

    if (diffMinutes < 1) return "Just now";
    if (diffMinutes < 60) return `${diffMinutes} min ago`;
    if (diffMinutes < 1440) return `${Math.floor(diffMinutes / 60)} hour ago`;
    return `${Math.floor(diffMinutes / 1440)} day ago`;
  };

  return (
    <div className="min-h-screen bg-beige-50 pb-20">
      {/* Header */}
      <div className="bg-white shadow-soft">
        <div className="px-4 py-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-2xl font-bold text-brown-500">Chats</h1>
              {!isDevelopmentMode && (
                <p className="text-xs text-green-600 font-medium">
                  Real Users ({allUsers.length} available)
                </p>
              )}
            </div>
            <UserSelector
              users={allUsers}
              onChatCreated={() => {
                if (isDevelopmentMode) {
                  // In demo mode, manually reload chats
                  const loadChats = async () => {
                    const userChats = await demoChatService.getUserChats(
                      user.uid,
                    );
                    setChats(userChats as any);
                  };
                  loadChats();
                }
                // In production mode, refresh happens automatically via real-time subscription
              }}
            />
          </div>

          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-brown-300 w-5 h-5" />
            <Input
              placeholder="Search conversations..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 py-3 rounded-xl border-sand-200 focus:border-rust-300"
            />
          </div>
        </div>
      </div>

      <div className="px-4 py-6">
        {/* Active Status */}
        <div className="mb-6">
          <h2 className="text-sm font-medium text-brown-400 mb-3">
            ACTIVE NOW
          </h2>
          <div className="flex space-x-4 overflow-x-auto pb-2">
            {[1, 2, 3, 4, 5].map((i) => (
              <div
                key={i}
                className="flex flex-col items-center space-y-2 min-w-fit"
              >
                <div className="relative">
                  <Avatar className="w-14 h-14">
                    <AvatarImage src="/placeholder.svg" />
                    <AvatarFallback className="bg-sand-200 text-brown-500">
                      U{i}
                    </AvatarFallback>
                  </Avatar>
                  <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 border-2 border-white rounded-full" />
                </div>
                <span className="text-xs text-brown-400 text-center">
                  User {i}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Chats */}
        <div>
          <h2 className="text-sm font-medium text-brown-400 mb-3">RECENT</h2>

          {loading ? (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="p-4 shadow-soft animate-pulse">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-sand-200 rounded-full"></div>
                    <div className="flex-1 space-y-2">
                      <div className="h-4 bg-sand-200 rounded w-3/4"></div>
                      <div className="h-3 bg-sand-200 rounded w-1/2"></div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          ) : filteredChats.length === 0 ? (
            <Card className="p-8 text-center shadow-soft">
              <MessageCircle className="w-12 h-12 text-brown-300 mx-auto mb-3" />
              <h3 className="font-medium text-brown-500 mb-2">No chats yet</h3>
              <p className="text-brown-400 text-sm mb-4">
                Start connecting with fellow alumni
              </p>
              {allUsers.length > 0 ? (
                <div className="flex flex-col items-center gap-3">
                  <UserSelector
                    users={allUsers}
                    onChatCreated={() => {
                      if (isDevelopmentMode) {
                        const loadChats = async () => {
                          const userChats = await demoChatService.getUserChats(
                            user.uid,
                          );
                          setChats(userChats as any);
                        };
                        loadChats();
                      }
                    }}
                  />
                  <p className="text-brown-300 text-xs">
                    Click + to choose someone to chat with
                  </p>
                </div>
              ) : (
                <div className="text-center">
                  <p className="text-brown-300 text-sm mb-2">
                    No other users found in your Firebase database
                  </p>
                  <p className="text-brown-400 text-xs">
                    Register more users or check your Firebase security rules
                  </p>
                </div>
              )}
            </Card>
          ) : (
            <div className="space-y-2">
              {filteredChats.map((chat) => {
                const chatName = chat.isGroup
                  ? chat.groupName
                  : chat.participantNames?.find(
                      (name) => name !== user?.displayName,
                    ) || "Unknown User";
                const unreadCount = chat.unreadCount?.[user?.uid || ""] || 0;

                return (
                  <Card
                    key={chat.id}
                    onClick={() => handleChatClick(chat.id!)}
                    className="p-4 shadow-soft hover:shadow-soft-lg transition-shadow cursor-pointer"
                  >
                    <div className="flex items-center space-x-4">
                      <div className="relative">
                        <Avatar className="w-12 h-12">
                          <AvatarImage
                            src={chat.groupAvatar || "/placeholder.svg"}
                          />
                          <AvatarFallback className="bg-sand-200 text-brown-500">
                            {chat.isGroup ? (
                              <MessageCircle className="w-6 h-6" />
                            ) : (
                              chatName.charAt(0)
                            )}
                          </AvatarFallback>
                        </Avatar>
                        {!chat.isGroup && (
                          <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-500 border-2 border-white rounded-full" />
                        )}
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <h3 className="font-medium text-brown-500 truncate">
                            {chatName}
                          </h3>
                          <span className="text-xs text-brown-300">
                            {formatTime(chat.lastMessageTime)}
                          </span>
                        </div>
                        <p className="text-sm text-brown-400 truncate">
                          {chat.lastMessage || "No messages yet"}
                        </p>
                      </div>

                      {unreadCount > 0 && (
                        <div className="w-5 h-5 bg-rust-500 text-white text-xs rounded-full flex items-center justify-center">
                          {unreadCount}
                        </div>
                      )}
                    </div>
                  </Card>
                );
              })}
            </div>
          )}
        </div>
      </div>

      <BottomNavigation />
    </div>
  );
};

export default Chat;
