import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Building2, Users, MapPin, Globe, Loader2 } from "lucide-react";
import { toast } from "sonner";

const CompanyOnboarding = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  const [formData, setFormData] = useState({
    companyName: "",
    companySize: "",
    industry: "",
    description: "",
    website: "",
    location: "",
    contactName: "",
    contactEmail: "",
    contactRole: "",
    phone: "",
    hiringNeeds: "",
  });

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // In a real app, this would create a company profile
      console.log("Company onboarding data:", formData);

      toast.success("Company profile created! You can now post jobs.");
      navigate("/post-job");
    } catch (error: any) {
      console.error("Error creating company profile:", error);
      toast.error("Failed to create company profile");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-beige-50">
      {/* Header */}
      <div className="bg-white shadow-soft">
        <div className="px-4 py-6">
          <div className="text-center">
            <Building2 className="w-12 h-12 text-rust-500 mx-auto mb-3" />
            <h1 className="text-2xl font-semibold text-brown-500">
              Welcome to SAAN for Employers
            </h1>
            <p className="text-brown-400 mt-2">
              Connect with talented African alumni
            </p>
          </div>
        </div>
      </div>

      <div className="px-4 py-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Company Information */}
          <Card className="p-6 shadow-soft">
            <h3 className="text-lg font-semibold text-brown-500 mb-4 flex items-center">
              <Building2 className="w-5 h-5 mr-2" />
              Company Information
            </h3>
            <div className="space-y-4">
              <div>
                <Label
                  htmlFor="companyName"
                  className="text-brown-500 font-medium"
                >
                  Company Name *
                </Label>
                <Input
                  id="companyName"
                  name="companyName"
                  value={formData.companyName}
                  onChange={handleInputChange}
                  placeholder="Your company name"
                  required
                  className="mt-1 rounded-lg border-sand-200 focus:border-rust-300"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label
                    htmlFor="companySize"
                    className="text-brown-500 font-medium"
                  >
                    Company Size *
                  </Label>
                  <Select
                    value={formData.companySize}
                    onValueChange={(value) =>
                      setFormData((prev) => ({ ...prev, companySize: value }))
                    }
                  >
                    <SelectTrigger className="mt-1 rounded-lg border-sand-200 focus:border-rust-300">
                      <SelectValue placeholder="Select size" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1-10">1-10 employees</SelectItem>
                      <SelectItem value="11-50">11-50 employees</SelectItem>
                      <SelectItem value="51-200">51-200 employees</SelectItem>
                      <SelectItem value="201-500">201-500 employees</SelectItem>
                      <SelectItem value="500+">500+ employees</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label
                    htmlFor="industry"
                    className="text-brown-500 font-medium"
                  >
                    Industry *
                  </Label>
                  <Select
                    value={formData.industry}
                    onValueChange={(value) =>
                      setFormData((prev) => ({ ...prev, industry: value }))
                    }
                  >
                    <SelectTrigger className="mt-1 rounded-lg border-sand-200 focus:border-rust-300">
                      <SelectValue placeholder="Select industry" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="technology">Technology</SelectItem>
                      <SelectItem value="finance">Finance</SelectItem>
                      <SelectItem value="healthcare">Healthcare</SelectItem>
                      <SelectItem value="education">Education</SelectItem>
                      <SelectItem value="manufacturing">
                        Manufacturing
                      </SelectItem>
                      <SelectItem value="consulting">Consulting</SelectItem>
                      <SelectItem value="government">Government</SelectItem>
                      <SelectItem value="ngo">NGO/Non-profit</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label
                  htmlFor="description"
                  className="text-brown-500 font-medium"
                >
                  Company Description *
                </Label>
                <Textarea
                  id="description"
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                  placeholder="Tell us about your company, mission, and values..."
                  required
                  rows={3}
                  className="mt-1 rounded-lg border-sand-200 focus:border-rust-300"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label
                    htmlFor="website"
                    className="text-brown-500 font-medium"
                  >
                    Website
                  </Label>
                  <Input
                    id="website"
                    name="website"
                    value={formData.website}
                    onChange={handleInputChange}
                    placeholder="https://yourcompany.com"
                    className="mt-1 rounded-lg border-sand-200 focus:border-rust-300"
                  />
                </div>

                <div>
                  <Label
                    htmlFor="location"
                    className="text-brown-500 font-medium"
                  >
                    Location *
                  </Label>
                  <Input
                    id="location"
                    name="location"
                    value={formData.location}
                    onChange={handleInputChange}
                    placeholder="City, Country"
                    required
                    className="mt-1 rounded-lg border-sand-200 focus:border-rust-300"
                  />
                </div>
              </div>
            </div>
          </Card>

          {/* Contact Information */}
          <Card className="p-6 shadow-soft">
            <h3 className="text-lg font-semibold text-brown-500 mb-4 flex items-center">
              <Users className="w-5 h-5 mr-2" />
              Contact Information
            </h3>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label
                    htmlFor="contactName"
                    className="text-brown-500 font-medium"
                  >
                    Contact Name *
                  </Label>
                  <Input
                    id="contactName"
                    name="contactName"
                    value={formData.contactName}
                    onChange={handleInputChange}
                    placeholder="Your full name"
                    required
                    className="mt-1 rounded-lg border-sand-200 focus:border-rust-300"
                  />
                </div>

                <div>
                  <Label
                    htmlFor="contactRole"
                    className="text-brown-500 font-medium"
                  >
                    Your Role *
                  </Label>
                  <Input
                    id="contactRole"
                    name="contactRole"
                    value={formData.contactRole}
                    onChange={handleInputChange}
                    placeholder="e.g. HR Manager"
                    required
                    className="mt-1 rounded-lg border-sand-200 focus:border-rust-300"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label
                    htmlFor="contactEmail"
                    className="text-brown-500 font-medium"
                  >
                    Email *
                  </Label>
                  <Input
                    id="contactEmail"
                    name="contactEmail"
                    type="email"
                    value={formData.contactEmail}
                    onChange={handleInputChange}
                    placeholder="your.email@company.com"
                    required
                    className="mt-1 rounded-lg border-sand-200 focus:border-rust-300"
                  />
                </div>

                <div>
                  <Label htmlFor="phone" className="text-brown-500 font-medium">
                    Phone
                  </Label>
                  <Input
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    placeholder="+27 123 456 789"
                    className="mt-1 rounded-lg border-sand-200 focus:border-rust-300"
                  />
                </div>
              </div>
            </div>
          </Card>

          {/* Hiring Needs */}
          <Card className="p-6 shadow-soft">
            <h3 className="text-lg font-semibold text-brown-500 mb-4">
              Hiring Needs
            </h3>
            <div>
              <Label
                htmlFor="hiringNeeds"
                className="text-brown-500 font-medium"
              >
                What types of talent are you looking for?
              </Label>
              <Textarea
                id="hiringNeeds"
                name="hiringNeeds"
                value={formData.hiringNeeds}
                onChange={handleInputChange}
                placeholder="Describe the roles, skills, and experience levels you typically hire for..."
                rows={3}
                className="mt-1 rounded-lg border-sand-200 focus:border-rust-300"
              />
            </div>
          </Card>

          {/* Benefits */}
          <Card className="p-6 shadow-soft bg-gradient-to-r from-rust-50 to-sand-50 border-rust-100">
            <h3 className="text-lg font-semibold text-brown-500 mb-3">
              Why SAAN for Employers?
            </h3>
            <div className="space-y-3 text-sm text-brown-400">
              <div className="flex items-center">
                <Globe className="w-4 h-4 mr-2 text-rust-500" />
                <span>Access to 50,000+ African alumni worldwide</span>
              </div>
              <div className="flex items-center">
                <Users className="w-4 h-4 mr-2 text-rust-500" />
                <span>Pre-qualified, university-educated professionals</span>
              </div>
              <div className="flex items-center">
                <MapPin className="w-4 h-4 mr-2 text-rust-500" />
                <span>Local talent with global experience</span>
              </div>
            </div>
          </Card>

          {/* Submit */}
          <div className="pb-6">
            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-rust-500 hover:bg-rust-600 text-white py-3 rounded-lg font-medium disabled:opacity-50"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Creating Profile...
                </>
              ) : (
                "Create Company Profile"
              )}
            </Button>

            <p className="text-center text-brown-400 text-sm mt-4">
              By creating a profile, you agree to our Terms of Service and can
              start posting jobs immediately.
            </p>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CompanyOnboarding;
