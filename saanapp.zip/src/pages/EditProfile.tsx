import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ArrowLeft, Camera, Loader2, Plus, X } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";

const EditProfile = () => {
  const navigate = useNavigate();
  const { user, userProfile, updateUserProfile } = useAuth();
  const [loading, setLoading] = useState(false);
  const [skills, setSkills] = useState<string[]>([]);
  const [interests, setInterests] = useState<string[]>([]);
  const [newSkill, setNewSkill] = useState("");
  const [newInterest, setNewInterest] = useState("");

  const [formData, setFormData] = useState({
    displayName: "",
    bio: "",
    location: "",
    university: "",
    graduationYear: "",
    fieldOfStudy: "",
    currentRole: "",
    company: "",
  });

  useEffect(() => {
    if (!user) {
      navigate("/welcome");
      return;
    }

    if (userProfile) {
      setFormData({
        displayName: userProfile.displayName || "",
        bio: userProfile.bio || "",
        location: userProfile.location || "",
        university: userProfile.university || "",
        graduationYear: userProfile.graduationYear || "",
        fieldOfStudy: userProfile.fieldOfStudy || "",
        currentRole: userProfile.currentRole || "",
        company: userProfile.company || "",
      });
      setSkills(userProfile.skills || []);
      setInterests(userProfile.interests || []);
    }
  }, [user, userProfile, navigate]);

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const addSkill = () => {
    if (newSkill.trim() && !skills.includes(newSkill.trim())) {
      setSkills([...skills, newSkill.trim()]);
      setNewSkill("");
    }
  };

  const removeSkill = (skillToRemove: string) => {
    setSkills(skills.filter((skill) => skill !== skillToRemove));
  };

  const addInterest = () => {
    if (newInterest.trim() && !interests.includes(newInterest.trim())) {
      setInterests([...interests, newInterest.trim()]);
      setNewInterest("");
    }
  };

  const removeInterest = (interestToRemove: string) => {
    setInterests(interests.filter((interest) => interest !== interestToRemove));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      await updateUserProfile({
        ...formData,
        skills,
        interests,
      });
      toast.success("Profile updated successfully!");
      navigate("/profile");
    } catch (error: any) {
      console.error("Error updating profile:", error);
      toast.error("Failed to update profile");
    } finally {
      setLoading(false);
    }
  };

  if (!user || !userProfile) {
    return (
      <div className="min-h-screen bg-beige-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-rust-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-brown-500">Loading profile...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-beige-50">
      {/* Header */}
      <div className="bg-white shadow-soft">
        <div className="px-4 py-6">
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate("/profile")}
              className="text-brown-400"
            >
              <ArrowLeft className="w-6 h-6" />
            </Button>
            <h1 className="text-xl font-semibold text-brown-500">
              Edit Profile
            </h1>
            <div className="w-10" />
          </div>
        </div>
      </div>

      <div className="px-4 py-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Profile Picture */}
          <Card className="p-6 shadow-soft">
            <div className="text-center">
              <div className="relative inline-block">
                <Avatar className="w-24 h-24">
                  <AvatarImage
                    src={userProfile.photoURL || "/placeholder.svg"}
                  />
                  <AvatarFallback className="bg-rust-100 text-rust-600 text-2xl">
                    {formData.displayName.charAt(0) || "U"}
                  </AvatarFallback>
                </Avatar>
                <Button
                  type="button"
                  size="icon"
                  className="absolute -bottom-2 -right-2 w-8 h-8 bg-rust-500 hover:bg-rust-600 text-white rounded-full"
                >
                  <Camera className="w-4 h-4" />
                </Button>
              </div>
              <p className="text-brown-400 text-sm mt-2">Tap to change photo</p>
            </div>
          </Card>

          {/* Basic Information */}
          <Card className="p-6 shadow-soft">
            <h3 className="text-lg font-semibold text-brown-500 mb-4">
              Basic Information
            </h3>
            <div className="space-y-4">
              <div>
                <Label
                  htmlFor="displayName"
                  className="text-brown-500 font-medium"
                >
                  Full Name
                </Label>
                <Input
                  id="displayName"
                  name="displayName"
                  value={formData.displayName}
                  onChange={handleInputChange}
                  className="mt-1 rounded-lg border-sand-200 focus:border-rust-300"
                />
              </div>

              <div>
                <Label htmlFor="bio" className="text-brown-500 font-medium">
                  Bio
                </Label>
                <Textarea
                  id="bio"
                  name="bio"
                  value={formData.bio}
                  onChange={handleInputChange}
                  placeholder="Tell us about yourself..."
                  className="mt-1 rounded-lg border-sand-200 focus:border-rust-300"
                  rows={3}
                />
              </div>

              <div>
                <Label
                  htmlFor="location"
                  className="text-brown-500 font-medium"
                >
                  Location
                </Label>
                <Input
                  id="location"
                  name="location"
                  value={formData.location}
                  onChange={handleInputChange}
                  placeholder="City, Country"
                  className="mt-1 rounded-lg border-sand-200 focus:border-rust-300"
                />
              </div>
            </div>
          </Card>

          {/* Education */}
          <Card className="p-6 shadow-soft">
            <h3 className="text-lg font-semibold text-brown-500 mb-4">
              Education
            </h3>
            <div className="space-y-4">
              <div>
                <Label
                  htmlFor="university"
                  className="text-brown-500 font-medium"
                >
                  University
                </Label>
                <Input
                  id="university"
                  name="university"
                  value={formData.university}
                  onChange={handleInputChange}
                  placeholder="University of Cape Town"
                  className="mt-1 rounded-lg border-sand-200 focus:border-rust-300"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label
                    htmlFor="fieldOfStudy"
                    className="text-brown-500 font-medium"
                  >
                    Field of Study
                  </Label>
                  <Input
                    id="fieldOfStudy"
                    name="fieldOfStudy"
                    value={formData.fieldOfStudy}
                    onChange={handleInputChange}
                    placeholder="Computer Science"
                    className="mt-1 rounded-lg border-sand-200 focus:border-rust-300"
                  />
                </div>

                <div>
                  <Label
                    htmlFor="graduationYear"
                    className="text-brown-500 font-medium"
                  >
                    Graduation Year
                  </Label>
                  <Select
                    value={formData.graduationYear}
                    onValueChange={(value) =>
                      setFormData((prev) => ({
                        ...prev,
                        graduationYear: value,
                      }))
                    }
                  >
                    <SelectTrigger className="mt-1 rounded-lg border-sand-200 focus:border-rust-300">
                      <SelectValue placeholder="Select year" />
                    </SelectTrigger>
                    <SelectContent>
                      {Array.from(
                        { length: 30 },
                        (_, i) => new Date().getFullYear() - i,
                      ).map((year) => (
                        <SelectItem key={year} value={year.toString()}>
                          {year}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </Card>

          {/* Professional */}
          <Card className="p-6 shadow-soft">
            <h3 className="text-lg font-semibold text-brown-500 mb-4">
              Professional
            </h3>
            <div className="space-y-4">
              <div>
                <Label
                  htmlFor="currentRole"
                  className="text-brown-500 font-medium"
                >
                  Current Role
                </Label>
                <Input
                  id="currentRole"
                  name="currentRole"
                  value={formData.currentRole}
                  onChange={handleInputChange}
                  placeholder="Software Engineer"
                  className="mt-1 rounded-lg border-sand-200 focus:border-rust-300"
                />
              </div>

              <div>
                <Label htmlFor="company" className="text-brown-500 font-medium">
                  Company
                </Label>
                <Input
                  id="company"
                  name="company"
                  value={formData.company}
                  onChange={handleInputChange}
                  placeholder="Tech Company"
                  className="mt-1 rounded-lg border-sand-200 focus:border-rust-300"
                />
              </div>
            </div>
          </Card>

          {/* Skills */}
          <Card className="p-6 shadow-soft">
            <h3 className="text-lg font-semibold text-brown-500 mb-4">
              Skills
            </h3>
            <div className="space-y-3">
              <div className="flex space-x-2">
                <Input
                  value={newSkill}
                  onChange={(e) => setNewSkill(e.target.value)}
                  placeholder="Add a skill"
                  className="flex-1 rounded-lg border-sand-200 focus:border-rust-300"
                  onKeyPress={(e) =>
                    e.key === "Enter" && (e.preventDefault(), addSkill())
                  }
                />
                <Button
                  type="button"
                  onClick={addSkill}
                  className="bg-rust-500 hover:bg-rust-600 text-white rounded-lg"
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
              <div className="flex flex-wrap gap-2">
                {skills.map((skill) => (
                  <div
                    key={skill}
                    className="bg-sand-100 text-brown-600 px-3 py-1 rounded-full text-sm flex items-center"
                  >
                    {skill}
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => removeSkill(skill)}
                      className="ml-1 h-4 w-4 text-brown-400 hover:text-brown-600"
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          </Card>

          {/* Interests */}
          <Card className="p-6 shadow-soft">
            <h3 className="text-lg font-semibold text-brown-500 mb-4">
              Interests
            </h3>
            <div className="space-y-3">
              <div className="flex space-x-2">
                <Input
                  value={newInterest}
                  onChange={(e) => setNewInterest(e.target.value)}
                  placeholder="Add an interest"
                  className="flex-1 rounded-lg border-sand-200 focus:border-rust-300"
                  onKeyPress={(e) =>
                    e.key === "Enter" && (e.preventDefault(), addInterest())
                  }
                />
                <Button
                  type="button"
                  onClick={addInterest}
                  className="bg-rust-500 hover:bg-rust-600 text-white rounded-lg"
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
              <div className="flex flex-wrap gap-2">
                {interests.map((interest) => (
                  <div
                    key={interest}
                    className="bg-olive-100 text-olive-700 px-3 py-1 rounded-full text-sm flex items-center"
                  >
                    {interest}
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => removeInterest(interest)}
                      className="ml-1 h-4 w-4 text-olive-500 hover:text-olive-700"
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          </Card>

          {/* Save Button */}
          <div className="pb-6">
            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-rust-500 hover:bg-rust-600 text-white py-3 rounded-lg font-medium disabled:opacity-50"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Saving Changes...
                </>
              ) : (
                "Save Changes"
              )}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditProfile;
