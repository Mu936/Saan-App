import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  ArrowLeft,
  AlertTriangle,
  Phone,
  MapPin,
  Users,
  Clock,
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { isDevelopmentMode } from "@/lib/firebase";
import { collection, addDoc, Timestamp } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { toast } from "sonner";

const Emergency = () => {
  const navigate = useNavigate();
  const { user, userProfile } = useAuth();
  const [sosActivated, setSosActivated] = useState(false);
  const [creating, setCreating] = useState(false);

  const emergencyContacts = [
    {
      name: "SAAN Emergency Line",
      number: "+27 800 123 456",
      type: "24/7 Support",
    },
    { name: "Local Emergency", number: "112", type: "Police/Medical" },
    {
      name: "Alumni Crisis Team",
      number: "+27 800 789 012",
      type: "Crisis Support",
    },
  ];

  const handleSOS = async () => {
    if (!user) {
      toast.error("You must be logged in to send an emergency alert");
      navigate("/login");
      return;
    }

    setCreating(true);
    setSosActivated(true);

    try {
      // Create emergency alert that broadcasts to all users
      const emergencyAlert = {
        userId: user.uid,
        userName: userProfile?.displayName || user.displayName || "SAAN User",
        userPhone: userProfile?.phone || "+27 XXX XXX XXX",
        location: userProfile?.location || "Current Location",
        message: "Emergency assistance needed - please help if you're nearby!",
        timestamp: new Date(),
        coordinates: { lat: -26.2041, lng: 28.0473 }, // In production, get from GPS
        helpOffered: [],
        status: "active",
        type: "sos",
      };

      if (isDevelopmentMode) {
        // In development mode, just log the alert
        console.log("Demo emergency alert created:", emergencyAlert);
        toast.success(
          "🚨 DEMO EMERGENCY ALERT! (No real alert sent in demo mode)",
        );
      } else {
        // Save to Firebase and broadcast to all users
        const docRef = await addDoc(collection(db, "emergencies"), {
          ...emergencyAlert,
          timestamp: Timestamp.fromDate(emergencyAlert.timestamp),
        });

        console.log("Real emergency alert created with ID:", docRef.id);
        toast.success(
          "🚨 EMERGENCY ALERT SENT! All SAAN members have been notified.",
        );
      }

      // Show confirmation to user
      setTimeout(() => {
        setSosActivated(false);
        setCreating(false);

        const message = isDevelopmentMode
          ? "🚨 DEMO EMERGENCY ALERT!\n\n✅ In real mode, this would broadcast to all SAAN members\n✅ Nearby alumni would be notified\n✅ Community members could offer assistance"
          : "🚨 EMERGENCY ALERT SENT!\n\n✅ Your emergency has been broadcast to all SAAN members\n✅ Nearby alumni will be notified\n✅ Community members can offer assistance\n\nHelp is on the way!";

        alert(message);
      }, 3000);
    } catch (error) {
      console.error("Error creating emergency alert:", error);
      toast.error("Failed to send emergency alert. Please try again.");
      setSosActivated(false);
      setCreating(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-orange-50">
      {/* Header */}
      <div className="flex items-center justify-between p-4 bg-white shadow-soft">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => navigate("/home")}
          className="text-brown-400"
        >
          <ArrowLeft className="w-6 h-6" />
        </Button>
        <div className="text-center">
          <h1 className="text-xl font-semibold text-brown-500">
            Emergency SOS
          </h1>
          {isDevelopmentMode && (
            <p className="text-xs text-rust-500 font-medium">Demo Mode</p>
          )}
          {!isDevelopmentMode && (
            <p className="text-xs text-green-600 font-medium">
              Live Emergency System
            </p>
          )}
        </div>
        <div className="w-10" />
      </div>

      <div className="px-4 py-8">
        {/* Warning Banner */}
        <Card
          className={`p-4 mb-6 ${isDevelopmentMode ? "bg-blue-50 border-blue-200" : "bg-amber-50 border-amber-200"}`}
        >
          <div className="flex items-center space-x-3">
            <AlertTriangle
              className={`w-6 h-6 ${isDevelopmentMode ? "text-blue-600" : "text-amber-600"}`}
            />
            <div>
              <h3
                className={`font-medium ${isDevelopmentMode ? "text-blue-800" : "text-amber-800"}`}
              >
                {isDevelopmentMode
                  ? "Demo Mode - Safe Testing"
                  : "Emergency Use Only"}
              </h3>
              <p
                className={`text-sm ${isDevelopmentMode ? "text-blue-700" : "text-amber-700"}`}
              >
                {isDevelopmentMode
                  ? "This is demo mode - no real emergency alerts will be sent"
                  : "Use this feature only in genuine emergency situations"}
              </p>
            </div>
          </div>
        </Card>

        {/* SOS Button */}
        <div className="text-center mb-8">
          <div className="relative inline-block">
            <Button
              onClick={handleSOS}
              disabled={sosActivated || creating}
              className={`w-48 h-48 rounded-full text-white font-bold text-2xl shadow-lg transition-all ${
                sosActivated
                  ? "bg-green-500 animate-pulse"
                  : creating
                    ? "bg-orange-500 animate-pulse"
                    : "bg-red-500 hover:bg-red-600 active:scale-95"
              }`}
            >
              {sosActivated ? (
                <div className="flex flex-col items-center">
                  <Clock className="w-8 h-8 mb-2" />
                  <span className="text-lg">ALERT SENT</span>
                </div>
              ) : creating ? (
                <div className="flex flex-col items-center">
                  <Clock className="w-8 h-8 mb-2 animate-spin" />
                  <span className="text-lg">SENDING...</span>
                </div>
              ) : (
                <div className="flex flex-col items-center">
                  <AlertTriangle className="w-12 h-12 mb-2" />
                  <span>SOS</span>
                </div>
              )}
            </Button>
          </div>
          <p className="text-brown-500 mt-4 text-lg font-medium">
            {sosActivated
              ? `${isDevelopmentMode ? "Demo alert sent" : "All SAAN members notified"}`
              : creating
                ? "Creating emergency alert..."
                : "Tap to send emergency alert"}
          </p>
          <p className="text-brown-400 text-sm mt-2">
            Your location and emergency contacts will be notified
          </p>
        </div>

        {/* Current Location */}
        <Card className="p-4 mb-6 shadow-soft">
          <div className="flex items-center space-x-3 mb-3">
            <MapPin className="w-5 h-5 text-rust-500" />
            <h3 className="font-medium text-brown-500">Current Location</h3>
          </div>
          <p className="text-brown-400 text-sm">
            123 Main Street, Johannesburg, South Africa
          </p>
          <p className="text-brown-300 text-xs mt-1">
            Coordinates: -26.2041, 28.0473
          </p>
          <Button
            variant="outline"
            size="sm"
            className="mt-3 border-sand-200 text-brown-500"
          >
            Share Location
          </Button>
        </Card>

        {/* Emergency Contacts */}
        <div className="mb-6">
          <h3 className="text-lg font-semibold text-brown-500 mb-4 flex items-center">
            <Phone className="w-5 h-5 mr-2" />
            Emergency Contacts
          </h3>
          <div className="space-y-3">
            {emergencyContacts.map((contact, index) => (
              <Card key={index} className="p-4 shadow-soft">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium text-brown-500">
                      {contact.name}
                    </h4>
                    <p className="text-brown-400 text-sm">{contact.type}</p>
                    <p className="text-rust-600 font-medium">
                      {contact.number}
                    </p>
                  </div>
                  <Button
                    size="sm"
                    className="bg-rust-500 hover:bg-rust-600 text-white"
                  >
                    Call
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </div>

        {/* Nearby Alumni */}
        <Card className="p-4 shadow-soft">
          <div className="flex items-center space-x-3 mb-3">
            <Users className="w-5 h-5 text-olive-500" />
            <h3 className="font-medium text-brown-500">Nearby Alumni</h3>
          </div>
          <p className="text-brown-400 text-sm mb-3">
            2 SAAN members are within 5km of your location
          </p>
          <Button
            variant="outline"
            size="sm"
            className="border-sand-200 text-brown-500"
          >
            Contact Nearby Alumni
          </Button>
        </Card>
      </div>
    </div>
  );
};

export default Emergency;
