import {
  Bell,
  Search,
  MapPin,
  BookOpen,
  MessageCircle,
  Briefcase,
  AlertTriangle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { analyticsService } from "@/lib/firestore";
import { useEffect, useState } from "react";
import BottomNavigation from "@/components/BottomNavigation";

const Home = () => {
  const navigate = useNavigate();
  const { user, userProfile, logout } = useAuth();
  const [stats, setStats] = useState({
    connections: 0,
    opportunities: 0,
    events: 0,
  });

  useEffect(() => {
    // Redirect to welcome if not authenticated
    if (!user) {
      navigate("/welcome");
      return;
    }

    // Load user stats
    const loadStats = async () => {
      if (user) {
        try {
          const userStats = await analyticsService.getUserStats(user.uid);
          setStats(userStats);
        } catch (error) {
          console.error("Error loading stats:", error);
        }
      }
    };

    loadStats();
  }, [user, navigate]);

  const handleLogout = async () => {
    try {
      await logout();
      navigate("/welcome");
    } catch (error) {
      console.error("Logout error:", error);
    }
  };

  if (!user || !userProfile) {
    return (
      <div className="min-h-screen bg-beige-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-rust-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-brown-500">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  const quickLinks = [
    {
      icon: <Briefcase className="w-6 h-6" />,
      title: "Opportunities",
      description: "Find jobs & internships",
      color: "from-rust-500 to-rust-600",
      route: "/opportunities",
    },
    {
      icon: <MessageCircle className="w-6 h-6" />,
      title: "Chat",
      description: "Connect with alumni",
      color: "from-olive-500 to-olive-600",
      route: "/chat",
    },
    {
      icon: <BookOpen className="w-6 h-6" />,
      title: "E-Learning",
      description: "Skill development",
      color: "from-sand-400 to-sand-500",
      route: "/learning",
    },
    {
      icon: <AlertTriangle className="w-6 h-6" />,
      title: "Emergency SOS",
      description: "Get immediate help",
      color: "from-red-500 to-red-600",
      route: "/emergency",
    },
  ];

  const recentActivities = [
    {
      title: "New mentorship opportunity in Tech",
      time: "2 hours ago",
      type: "opportunity",
    },
    { title: "Alumni meetup in Cape Town", time: "1 day ago", type: "event" },
    { title: "Sarah joined your network", time: "2 days ago", type: "network" },
  ];

  return (
    <div className="min-h-screen bg-beige-50 pb-20">
      {/* Header */}
      <div className="bg-white shadow-soft">
        <div className="px-4 py-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-2xl font-bold text-brown-500">
                Good morning,{" "}
                {userProfile.displayName?.split(" ")[0] || "there"}
              </h1>
              <p className="text-brown-400 flex items-center">
                <MapPin className="w-4 h-4 mr-1" />
                {userProfile.location || "Location not set"}
              </p>
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="ghost" size="icon" className="text-brown-400">
                <Bell className="w-6 h-6" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleLogout}
                className="text-brown-400 text-xs"
              >
                Logout
              </Button>
            </div>
          </div>

          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-brown-300 w-5 h-5" />
            <Input
              placeholder="Search opportunities, people, events..."
              className="pl-10 py-3 rounded-xl border-sand-200 focus:border-rust-300"
            />
          </div>
        </div>
      </div>

      <div className="px-4 py-6">
        {/* Quick Stats */}
        <div className="grid grid-cols-3 gap-4 mb-8">
          <Card className="p-4 text-center shadow-soft">
            <div className="text-2xl font-bold text-rust-500">
              {stats.connections}
            </div>
            <div className="text-sm text-brown-400">Connections</div>
          </Card>
          <Card className="p-4 text-center shadow-soft">
            <div className="text-2xl font-bold text-olive-500">
              {stats.opportunities}
            </div>
            <div className="text-sm text-brown-400">Opportunities</div>
          </Card>
          <Card className="p-4 text-center shadow-soft">
            <div className="text-2xl font-bold text-sand-500">
              {stats.events}
            </div>
            <div className="text-sm text-brown-400">Events</div>
          </Card>
        </div>

        {/* Quick Links */}
        <div className="mb-8">
          <h2 className="text-xl font-semibold text-brown-500 mb-4">
            Quick Access
          </h2>
          <div className="grid grid-cols-2 gap-4">
            {quickLinks.map((link, index) => (
              <Card
                key={index}
                className="p-4 shadow-soft hover:shadow-soft-lg transition-shadow cursor-pointer"
                onClick={() => navigate(link.route)}
              >
                <div
                  className={`w-12 h-12 bg-gradient-to-br ${link.color} rounded-xl flex items-center justify-center text-white mb-3`}
                >
                  {link.icon}
                </div>
                <h3 className="font-semibold text-brown-500 mb-1">
                  {link.title}
                </h3>
                <p className="text-sm text-brown-400">{link.description}</p>
              </Card>
            ))}
          </div>
        </div>

        {/* Recent Activity */}
        <div className="mb-8">
          <h2 className="text-xl font-semibold text-brown-500 mb-4">
            Recent Activity
          </h2>
          <Card className="divide-y divide-sand-100 shadow-soft">
            {recentActivities.map((activity, index) => (
              <div
                key={index}
                className="p-4 flex items-center justify-between"
              >
                <div>
                  <p className="font-medium text-brown-500">{activity.title}</p>
                  <p className="text-sm text-brown-400">{activity.time}</p>
                </div>
                <div
                  className={`w-2 h-2 rounded-full ${
                    activity.type === "opportunity"
                      ? "bg-rust-500"
                      : activity.type === "event"
                        ? "bg-olive-500"
                        : "bg-sand-500"
                  }`}
                />
              </div>
            ))}
          </Card>
        </div>

        {/* Featured Content */}
        <div className="mb-6">
          <h2 className="text-xl font-semibold text-brown-500 mb-4">
            Featured for You
          </h2>
          <Card className="p-6 bg-gradient-to-r from-rust-50 to-sand-50 border-rust-100 shadow-soft">
            <div className="flex items-center mb-3">
              <div className="w-8 h-8 bg-rust-500 rounded-full flex items-center justify-center mr-3">
                <BookOpen className="w-4 h-4 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-brown-500">
                  Leadership Masterclass
                </h3>
                <p className="text-sm text-brown-400">Starting next week</p>
              </div>
            </div>
            <p className="text-brown-400 text-sm mb-4">
              Enhance your leadership skills with expert mentors from across
              Africa.
            </p>
            <Button className="bg-rust-500 hover:bg-rust-600 text-white rounded-lg px-6">
              Learn More
            </Button>
          </Card>
        </div>
      </div>

      <BottomNavigation />
    </div>
  );
};

export default Home;
