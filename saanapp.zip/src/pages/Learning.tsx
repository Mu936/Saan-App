import BottomNavigation from "@/components/BottomNavigation";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Search,
  Filter,
  BookOpen,
  Clock,
  Star,
  Play,
  Award,
  CheckCircle,
} from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { useAuth } from "@/hooks/useAuth";
import {
  learningService,
  type Course,
  type UserProgress,
} from "@/lib/firestore";
import { useEffect, useState } from "react";
import { toast } from "sonner";

const Learning = () => {
  const { user } = useAuth();
  const [courses, setCourses] = useState<Course[]>([]);
  const [userProgress, setUserProgress] = useState<UserProgress[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");

  const categories = [
    "All",
    "Leadership",
    "Technology",
    "Finance",
    "Marketing",
    "Healthcare",
  ];

  useEffect(() => {
    if (!user) return;

    const loadData = async () => {
      try {
        const [coursesData, progressData] = await Promise.all([
          learningService.getAllCourses(),
          learningService.getUserProgress(user.uid),
        ]);
        setCourses(coursesData);
        setUserProgress(progressData);
      } catch (error) {
        console.error("Error loading learning data:", error);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [user]);

  const filteredCourses = courses.filter((course) => {
    const matchesSearch =
      course.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      course.instructor.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory =
      selectedCategory === "All" || course.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getUserProgressForCourse = (courseId: string) => {
    return userProgress.find((p) => p.courseId === courseId);
  };

  const getProgressStats = () => {
    const enrolled = userProgress.length;
    const completed = userProgress.filter((p) => p.progress === 100).length;
    const totalHours = userProgress.reduce((acc, p) => {
      const course = courses.find((c) => c.id === p.courseId);
      if (course) {
        const hours = course.modules.reduce(
          (total, module) => total + module.duration / 60,
          0,
        );
        return acc + hours * (p.progress / 100);
      }
      return acc;
    }, 0);

    return { enrolled, completed, totalHours: Math.round(totalHours) };
  };

  const handleEnroll = async (courseId: string) => {
    if (!user) return;

    try {
      await learningService.enrollInCourse(user.uid, courseId);
      const updatedProgress = await learningService.getUserProgress(user.uid);
      setUserProgress(updatedProgress);
      toast.success("Successfully enrolled in course!");
    } catch (error) {
      console.error("Error enrolling in course:", error);
      toast.error("Failed to enroll in course");
    }
  };

  const stats = getProgressStats();

  return (
    <div className="min-h-screen bg-beige-50 pb-20">
      {/* Header */}
      <div className="bg-white shadow-soft">
        <div className="px-4 py-6">
          <h1 className="text-2xl font-bold text-brown-500 mb-4">E-Learning</h1>

          {/* Search and Filter */}
          <div className="flex space-x-3 mb-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-brown-300 w-5 h-5" />
              <Input
                placeholder="Search courses..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 py-3 rounded-xl border-sand-200 focus:border-rust-300"
              />
            </div>
            <Button
              variant="outline"
              size="icon"
              className="border-sand-200 text-brown-400 rounded-xl"
            >
              <Filter className="w-5 h-5" />
            </Button>
          </div>

          {/* Categories */}
          <div className="flex space-x-2 overflow-x-auto">
            {categories.map((category) => (
              <Button
                key={category}
                onClick={() => setSelectedCategory(category)}
                variant={category === selectedCategory ? "default" : "outline"}
                size="sm"
                className={`whitespace-nowrap rounded-full ${
                  category === selectedCategory
                    ? "bg-rust-500 hover:bg-rust-600 text-white"
                    : "border-sand-200 text-brown-400"
                }`}
              >
                {category}
              </Button>
            ))}
          </div>
        </div>
      </div>

      <div className="px-4 py-6">
        {/* Progress Summary */}
        <Card className="p-5 mb-6 bg-gradient-to-r from-olive-50 to-sand-50 border-olive-100 shadow-soft">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="font-semibold text-brown-500">
                Your Learning Journey
              </h3>
              <p className="text-brown-400 text-sm">
                {stats.enrolled > 0
                  ? "Keep up the great work!"
                  : "Start your learning journey today!"}
              </p>
            </div>
            <div className="w-12 h-12 bg-olive-500 rounded-lg flex items-center justify-center">
              <Award className="w-6 h-6 text-white" />
            </div>
          </div>
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-xl font-bold text-olive-600">
                {stats.enrolled}
              </div>
              <div className="text-xs text-brown-400">Enrolled</div>
            </div>
            <div>
              <div className="text-xl font-bold text-rust-500">
                {stats.completed}
              </div>
              <div className="text-xs text-brown-400">Completed</div>
            </div>
            <div>
              <div className="text-xl font-bold text-sand-600">
                {stats.totalHours}h
              </div>
              <div className="text-xs text-brown-400">Learned</div>
            </div>
          </div>
        </Card>

        {/* Continue Learning */}
        {userProgress.length > 0 && (
          <div className="mb-6">
            <h2 className="text-lg font-semibold text-brown-500 mb-4">
              Continue Learning
            </h2>
            {userProgress
              .filter((p) => p.progress > 0 && p.progress < 100)
              .slice(0, 1)
              .map((progress) => {
                const course = courses.find((c) => c.id === progress.courseId);
                if (!course) return null;

                return (
                  <Card key={progress.id} className="p-4 shadow-soft">
                    <div className="flex items-center space-x-4">
                      <div className="w-16 h-16 bg-rust-100 rounded-lg flex items-center justify-center">
                        <Play className="w-8 h-8 text-rust-500" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium text-brown-500">
                          {course.title}
                        </h3>
                        <p className="text-brown-400 text-sm mb-2">
                          {progress.currentModule ||
                            "Continue where you left off"}
                        </p>
                        <Progress value={progress.progress} className="h-2" />
                        <p className="text-brown-400 text-xs mt-1">
                          {progress.progress}% complete
                        </p>
                      </div>
                    </div>
                  </Card>
                );
              })}
          </div>
        )}

        {/* All Courses */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-brown-500">
              All Courses
            </h2>
            <Button variant="link" className="text-rust-500 p-0">
              View All
            </Button>
          </div>

          {loading ? (
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="p-4 shadow-soft animate-pulse">
                  <div className="flex space-x-4">
                    <div className="w-20 h-20 bg-sand-200 rounded-lg"></div>
                    <div className="flex-1 space-y-2">
                      <div className="h-4 bg-sand-200 rounded w-3/4"></div>
                      <div className="h-3 bg-sand-200 rounded w-1/2"></div>
                      <div className="h-3 bg-sand-200 rounded w-full"></div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              {filteredCourses.map((course) => {
                const progress = getUserProgressForCourse(course.id!);
                const isEnrolled = !!progress;
                const isCompleted = progress?.progress === 100;

                return (
                  <Card
                    key={course.id}
                    className="p-4 shadow-soft hover:shadow-soft-lg transition-shadow"
                  >
                    <div className="flex space-x-4">
                      <div className="w-20 h-20 bg-sand-200 rounded-lg flex items-center justify-center relative">
                        <BookOpen className="w-8 h-8 text-sand-600" />
                        {isCompleted && (
                          <div className="absolute -top-1 -right-1 w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                            <CheckCircle className="w-4 h-4 text-white" />
                          </div>
                        )}
                      </div>

                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <h3 className="font-semibold text-brown-500 mb-1">
                              {course.title}
                            </h3>
                            <p className="text-brown-400 text-sm">
                              by {course.instructor}
                            </p>
                          </div>
                          <div className="text-right">
                            <div className="flex items-center text-amber-500 text-sm">
                              <Star className="w-4 h-4 mr-1 fill-current" />
                              {course.rating}
                            </div>
                            <p className="text-brown-300 text-xs">
                              {course.enrolledUsers?.length || 0} enrolled
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center space-x-4 text-brown-400 text-sm mb-3">
                          <div className="flex items-center">
                            <Clock className="w-4 h-4 mr-1" />
                            {course.duration}
                          </div>
                          <span
                            className={`px-2 py-1 rounded-full text-xs ${
                              course.difficulty === "beginner"
                                ? "bg-green-100 text-green-700"
                                : course.difficulty === "intermediate"
                                  ? "bg-amber-100 text-amber-700"
                                  : "bg-red-100 text-red-700"
                            }`}
                          >
                            {course.difficulty.charAt(0).toUpperCase() +
                              course.difficulty.slice(1)}
                          </span>
                          <span className="px-2 py-1 bg-olive-100 text-olive-700 rounded-full text-xs">
                            {course.category}
                          </span>
                        </div>

                        {progress && progress.progress > 0 && (
                          <div className="mb-3">
                            <Progress
                              value={progress.progress}
                              className="h-2 mb-1"
                            />
                            <p className="text-brown-400 text-xs">
                              {progress.progress === 100
                                ? "Completed"
                                : `${progress.progress}% complete`}
                            </p>
                          </div>
                        )}

                        <div className="flex space-x-2">
                          {isCompleted ? (
                            <Button
                              variant="outline"
                              size="sm"
                              className="border-sand-200 text-brown-500"
                            >
                              <CheckCircle className="w-4 h-4 mr-2" />
                              Completed
                            </Button>
                          ) : isEnrolled ? (
                            <Button
                              size="sm"
                              className="bg-rust-500 hover:bg-rust-600 text-white"
                            >
                              Continue Learning
                            </Button>
                          ) : (
                            <Button
                              onClick={() => handleEnroll(course.id!)}
                              size="sm"
                              className="bg-rust-500 hover:bg-rust-600 text-white"
                            >
                              Enroll Now
                            </Button>
                          )}
                          <Button
                            variant="outline"
                            size="sm"
                            className="border-sand-200 text-brown-500"
                          >
                            Details
                          </Button>
                        </div>
                      </div>
                    </div>
                  </Card>
                );
              })}

              {filteredCourses.length === 0 && !loading && (
                <Card className="p-8 text-center shadow-soft">
                  <BookOpen className="w-12 h-12 text-brown-300 mx-auto mb-3" />
                  <h3 className="font-medium text-brown-500 mb-2">
                    No courses found
                  </h3>
                  <p className="text-brown-400 text-sm">
                    Try adjusting your search or category filter
                  </p>
                </Card>
              )}
            </div>
          )}
        </div>
      </div>

      <BottomNavigation />
    </div>
  );
};

export default Learning;
