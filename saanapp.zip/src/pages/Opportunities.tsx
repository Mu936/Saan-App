import BottomNavigation from "@/components/BottomNavigation";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  MapPin,
  Clock,
  Bookmark,
  Search,
  Filter,
  ExternalLink,
  Plus,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/hooks/useAuth";
import { opportunitiesService, type Opportunity } from "@/lib/firestore";
import { isDevelopmentMode } from "@/lib/firebase";
import { demoOpportunitiesService, type DemoOpportunity } from "@/lib/demoData";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";

const Opportunities = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [opportunities, setOpportunities] = useState<
    (Opportunity | DemoOpportunity)[]
  >([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedType, setSelectedType] = useState("All");
  const [savedJobs, setSavedJobs] = useState<Set<string>>(new Set());

  useEffect(() => {
    if (!user) return;

    if (isDevelopmentMode) {
      // Use demo data in development mode
      const unsubscribe = demoOpportunitiesService.subscribeToOpportunities(
        (data) => {
          setOpportunities(data);
          setLoading(false);
        },
      );
      return () => unsubscribe();
    } else {
      // Use Firebase in production
      const unsubscribe = opportunitiesService.subscribeToOpportunities(
        (data) => {
          setOpportunities(data);
          setLoading(false);
        },
      );
      return () => unsubscribe();
    }
  }, [user]);

  const filteredOpportunities = opportunities.filter((job) => {
    const matchesSearch =
      job.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      job.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
      job.location.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType =
      selectedType === "All" ||
      job.type.toLowerCase() === selectedType.toLowerCase() ||
      (selectedType === "Remote" && job.type === "remote");
    return matchesSearch && matchesType;
  });

  const handleApply = async (opportunityId: string) => {
    if (!user) return;

    try {
      if (isDevelopmentMode) {
        await demoOpportunitiesService.apply(opportunityId, user.uid);
      } else {
        await opportunitiesService.apply(opportunityId, user.uid);
      }
      toast.success("Application submitted successfully!");
    } catch (error) {
      console.error("Error applying:", error);
      toast.error("Failed to submit application");
    }
  };

  const toggleSaved = (jobId: string) => {
    const newSaved = new Set(savedJobs);
    if (newSaved.has(jobId)) {
      newSaved.delete(jobId);
      toast.success("Removed from saved jobs");
    } else {
      newSaved.add(jobId);
      toast.success("Added to saved jobs");
    }
    setSavedJobs(newSaved);
  };

  const formatDate = (date: Date) => {
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - date.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays === 1) return "1 day ago";
    if (diffDays < 7) return `${diffDays} days ago`;
    if (diffDays < 14) return "1 week ago";
    return `${Math.floor(diffDays / 7)} weeks ago`;
  };

  return (
    <div className="min-h-screen bg-beige-50 pb-20">
      {/* Header */}
      <div className="bg-white shadow-soft">
        <div className="px-4 py-6">
          <h1 className="text-2xl font-bold text-brown-500 mb-4">
            Opportunities
          </h1>

          {/* Search and Filter */}
          <div className="flex space-x-3 mb-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-brown-300 w-5 h-5" />
              <Input
                placeholder="Search jobs, internships..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 py-3 rounded-xl border-sand-200 focus:border-rust-300"
              />
            </div>
            <Button
              variant="outline"
              size="icon"
              className="border-sand-200 text-brown-400 rounded-xl"
            >
              <Filter className="w-5 h-5" />
            </Button>
          </div>

          {/* Quick Filters */}
          <div className="flex space-x-2 overflow-x-auto">
            {["All", "Full-time", "Remote", "Internship", "Contract"].map(
              (filter) => (
                <Button
                  key={filter}
                  onClick={() => setSelectedType(filter)}
                  variant={filter === selectedType ? "default" : "outline"}
                  size="sm"
                  className={`whitespace-nowrap rounded-full ${
                    filter === selectedType
                      ? "bg-rust-500 hover:bg-rust-600 text-white"
                      : "border-sand-200 text-brown-400"
                  }`}
                >
                  {filter}
                </Button>
              ),
            )}
          </div>
        </div>
      </div>

      <div className="px-4 py-6">
        <div className="flex items-center justify-between mb-4">
          <p className="text-brown-400">
            Found {filteredOpportunities.length} opportunities
          </p>
          <Button variant="link" className="text-rust-500 p-0">
            Sort by: Latest
          </Button>
        </div>

        {loading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="p-5 shadow-soft animate-pulse">
                <div className="space-y-3">
                  <div className="h-4 bg-sand-200 rounded w-3/4"></div>
                  <div className="h-3 bg-sand-200 rounded w-1/2"></div>
                  <div className="h-3 bg-sand-200 rounded w-full"></div>
                </div>
              </Card>
            ))}
          </div>
        ) : (
          /* Job Cards */
          <div className="space-y-4">
            {filteredOpportunities.map((job) => (
              <Card
                key={job.id}
                className="p-5 shadow-soft hover:shadow-soft-lg transition-shadow"
              >
                <div className="flex justify-between items-start mb-3">
                  <div className="flex-1">
                    <h3 className="font-semibold text-brown-500 text-lg mb-1">
                      {job.title}
                    </h3>
                    <p className="text-brown-400 font-medium">{job.company}</p>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => toggleSaved(job.id!)}
                    className={`${
                      savedJobs.has(job.id!)
                        ? "text-rust-500"
                        : "text-brown-300"
                    }`}
                  >
                    <Bookmark
                      className={`w-5 h-5 ${
                        savedJobs.has(job.id!) ? "fill-current" : ""
                      }`}
                    />
                  </Button>
                </div>

                <div className="space-y-2 mb-4">
                  <div className="flex items-center text-brown-400 text-sm">
                    <MapPin className="w-4 h-4 mr-2" />
                    {job.location} • {job.type}
                  </div>
                  <div className="flex items-center text-brown-400 text-sm">
                    <Clock className="w-4 h-4 mr-2" />
                    Posted {formatDate(job.postedAt)}
                  </div>
                  <div className="text-olive-600 font-medium">{job.salary}</div>
                </div>

                {job.description && (
                  <p className="text-brown-400 text-sm mb-4 line-clamp-2">
                    {job.description}
                  </p>
                )}

                <div className="flex space-x-3">
                  <Button
                    onClick={() => handleApply(job.id!)}
                    disabled={job.applications?.includes(user?.uid || "")}
                    className="flex-1 bg-rust-500 hover:bg-rust-600 text-white rounded-lg disabled:opacity-50"
                  >
                    {job.applications?.includes(user?.uid || "") ? (
                      "Applied"
                    ) : (
                      <>
                        Apply Now
                        <ExternalLink className="w-4 h-4 ml-2" />
                      </>
                    )}
                  </Button>
                  <Button
                    variant="outline"
                    className="border-sand-200 text-brown-500 rounded-lg"
                  >
                    View Details
                  </Button>
                </div>
              </Card>
            ))}

            {filteredOpportunities.length === 0 && !loading && (
              <Card className="p-8 text-center shadow-soft">
                <div className="text-brown-400 mb-2">
                  No opportunities found
                </div>
                <p className="text-brown-300 text-sm">
                  Try adjusting your search or filters
                </p>
              </Card>
            )}
          </div>
        )}
      </div>

      {/* Floating Action Button for Posting Jobs */}
      <Button
        onClick={() => navigate("/post-job")}
        className="fixed bottom-24 right-4 w-14 h-14 bg-rust-500 hover:bg-rust-600 text-white rounded-full shadow-lg hover:shadow-xl transition-all z-50"
      >
        <Plus className="w-6 h-6" />
      </Button>

      <BottomNavigation />
    </div>
  );
};

export default Opportunities;
