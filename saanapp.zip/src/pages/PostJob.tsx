import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ArrowLeft, Plus, X, Loader2, Building2 } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { isDevelopmentMode } from "@/lib/firebase";
import { opportunitiesService } from "@/lib/firestore";
import { demoOpportunitiesService } from "@/lib/demoData";
import { toast } from "sonner";
const PostJob = () => {
  const navigate = useNavigate();
  const { user, userProfile } = useAuth();
  const [loading, setLoading] = useState(false);
  const [requirements, setRequirements] = useState<string[]>([]);
  const [benefits, setBenefits] = useState<string[]>([]);
  const [newRequirement, setNewRequirement] = useState("");
  const [newBenefit, setNewBenefit] = useState("");

  const [formData, setFormData] = useState({
    title: "",
    company: userProfile?.company || "",
    location: "",
    type: "",
    salary: "",
    description: "",
  });

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const addRequirement = () => {
    if (
      newRequirement.trim() &&
      !requirements.includes(newRequirement.trim())
    ) {
      setRequirements([...requirements, newRequirement.trim()]);
      setNewRequirement("");
    }
  };

  const removeRequirement = (req: string) => {
    setRequirements(requirements.filter((r) => r !== req));
  };

  const addBenefit = () => {
    if (newBenefit.trim() && !benefits.includes(newBenefit.trim())) {
      setBenefits([...benefits, newBenefit.trim()]);
      setNewBenefit("");
    }
  };

  const removeBenefit = (benefit: string) => {
    setBenefits(benefits.filter((b) => b !== benefit));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!user) {
      toast.error("You must be logged in to post a job");
      navigate("/login");
      return;
    }

    console.log("Current user:", user.uid, user.email);
    console.log("User profile:", userProfile);
    setLoading(true);

    try {
      const jobData = {
        ...formData,
        type: formData.type as
          | "full-time"
          | "part-time"
          | "contract"
          | "internship"
          | "remote",
        requirements,
        benefits,
        postedBy: user.uid,
        postedAt: new Date(),
        applications: [],
        isActive: true,
      };

      console.log("Creating job with data:", jobData);

      if (isDevelopmentMode) {
        // Use demo service in development
        await demoOpportunitiesService.create(jobData);
        console.log("Demo job created successfully");
      } else {
        // Use real Firebase service
        const jobId = await opportunitiesService.create(jobData);
        console.log("Real job created successfully with ID:", jobId);
      }

      toast.success("🎉 Job posted successfully and is now live!");
      navigate("/opportunities");
    } catch (error: any) {
      console.error("Error posting job:", error);
      toast.error("Failed to post job: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    navigate("/welcome");
    return null;
  }

  return (
    <div className="min-h-screen bg-beige-50">
      {/* Header */}
      <div className="bg-white shadow-soft">
        <div className="px-4 py-6">
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate("/opportunities")}
              className="text-brown-400"
            >
              <ArrowLeft className="w-6 h-6" />
            </Button>
            <div className="text-center">
              <h1 className="text-xl font-semibold text-brown-500">
                Share an Opportunity
              </h1>
              {isDevelopmentMode && (
                <p className="text-xs text-rust-500 font-medium">Demo Mode</p>
              )}
              {!isDevelopmentMode && (
                <p className="text-xs text-green-600 font-medium">
                  Real Firebase Mode
                </p>
              )}
            </div>
            <div className="w-10" />
          </div>
        </div>
      </div>

      <div className="px-4 py-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Employer Info */}
          <Card className="p-6 shadow-soft">
            <div className="flex items-center mb-4">
              <Building2 className="w-5 h-5 text-rust-500 mr-2" />
              <h3 className="text-lg font-semibold text-brown-500">
                Your Information
              </h3>
            </div>
            <div className="space-y-4">
              <div>
                <Label htmlFor="company" className="text-brown-500 font-medium">
                  Company/Organization *
                </Label>
                <Input
                  id="company"
                  name="company"
                  value={formData.company}
                  onChange={handleInputChange}
                  placeholder="Your company, startup, or organization"
                  required
                  className="mt-1 rounded-lg border-sand-200 focus:border-rust-300"
                />
              </div>
            </div>
          </Card>

          {/* Job Details */}
          <Card className="p-6 shadow-soft">
            <h3 className="text-lg font-semibold text-brown-500 mb-4">
              Job Details
            </h3>
            <div className="space-y-4">
              <div>
                <Label htmlFor="title" className="text-brown-500 font-medium">
                  Job Title *
                </Label>
                <Input
                  id="title"
                  name="title"
                  value={formData.title}
                  onChange={handleInputChange}
                  placeholder="e.g. Senior Software Engineer"
                  required
                  className="mt-1 rounded-lg border-sand-200 focus:border-rust-300"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label
                    htmlFor="location"
                    className="text-brown-500 font-medium"
                  >
                    Location *
                  </Label>
                  <Input
                    id="location"
                    name="location"
                    value={formData.location}
                    onChange={handleInputChange}
                    placeholder="City, Country"
                    required
                    className="mt-1 rounded-lg border-sand-200 focus:border-rust-300"
                  />
                </div>

                <div>
                  <Label htmlFor="type" className="text-brown-500 font-medium">
                    Job Type *
                  </Label>
                  <Select
                    value={formData.type}
                    onValueChange={(value) =>
                      setFormData((prev) => ({ ...prev, type: value }))
                    }
                  >
                    <SelectTrigger className="mt-1 rounded-lg border-sand-200 focus:border-rust-300">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="full-time">Full-time</SelectItem>
                      <SelectItem value="part-time">Part-time</SelectItem>
                      <SelectItem value="contract">Contract</SelectItem>
                      <SelectItem value="internship">Internship</SelectItem>
                      <SelectItem value="remote">Remote</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="salary" className="text-brown-500 font-medium">
                  Salary Range
                </Label>
                <Input
                  id="salary"
                  name="salary"
                  value={formData.salary}
                  onChange={handleInputChange}
                  placeholder="e.g. R 50,000 - R 80,000"
                  className="mt-1 rounded-lg border-sand-200 focus:border-rust-300"
                />
              </div>

              <div>
                <Label
                  htmlFor="description"
                  className="text-brown-500 font-medium"
                >
                  Job Description *
                </Label>
                <Textarea
                  id="description"
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                  placeholder="Describe the role, responsibilities, and what you're looking for..."
                  required
                  rows={4}
                  className="mt-1 rounded-lg border-sand-200 focus:border-rust-300"
                />
              </div>
            </div>
          </Card>

          {/* Requirements */}
          <Card className="p-6 shadow-soft">
            <h3 className="text-lg font-semibold text-brown-500 mb-4">
              Requirements
            </h3>
            <div className="space-y-3">
              <div className="flex space-x-2">
                <Input
                  value={newRequirement}
                  onChange={(e) => setNewRequirement(e.target.value)}
                  placeholder="Add a requirement"
                  className="flex-1 rounded-lg border-sand-200 focus:border-rust-300"
                  onKeyPress={(e) =>
                    e.key === "Enter" && (e.preventDefault(), addRequirement())
                  }
                />
                <Button
                  type="button"
                  onClick={addRequirement}
                  className="bg-rust-500 hover:bg-rust-600 text-white rounded-lg"
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
              <div className="flex flex-wrap gap-2">
                {requirements.map((req) => (
                  <div
                    key={req}
                    className="bg-sand-100 text-brown-600 px-3 py-1 rounded-full text-sm flex items-center"
                  >
                    {req}
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => removeRequirement(req)}
                      className="ml-1 h-4 w-4 text-brown-400 hover:text-brown-600"
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          </Card>

          {/* Benefits */}
          <Card className="p-6 shadow-soft">
            <h3 className="text-lg font-semibold text-brown-500 mb-4">
              Benefits & Perks
            </h3>
            <div className="space-y-3">
              <div className="flex space-x-2">
                <Input
                  value={newBenefit}
                  onChange={(e) => setNewBenefit(e.target.value)}
                  placeholder="Add a benefit"
                  className="flex-1 rounded-lg border-sand-200 focus:border-rust-300"
                  onKeyPress={(e) =>
                    e.key === "Enter" && (e.preventDefault(), addBenefit())
                  }
                />
                <Button
                  type="button"
                  onClick={addBenefit}
                  className="bg-olive-500 hover:bg-olive-600 text-white rounded-lg"
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
              <div className="flex flex-wrap gap-2">
                {benefits.map((benefit) => (
                  <div
                    key={benefit}
                    className="bg-olive-100 text-olive-700 px-3 py-1 rounded-full text-sm flex items-center"
                  >
                    {benefit}
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => removeBenefit(benefit)}
                      className="ml-1 h-4 w-4 text-olive-500 hover:text-olive-700"
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          </Card>

          {/* Submit */}
          <div className="pb-6">
            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-rust-500 hover:bg-rust-600 text-white py-3 rounded-lg font-medium disabled:opacity-50"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Posting Job...
                </>
              ) : (
                "Post Job"
              )}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default PostJob;
