import BottomNavigation from "@/components/BottomNavigation";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Settings,
  Edit3,
  Users,
  Award,
  BookOpen,
  MapPin,
  Calendar,
  Globe,
  LogOut,
} from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useAuth } from "@/hooks/useAuth";
import { useNavigate } from "react-router-dom";
import { useEffect } from "react";

const Profile = () => {
  const navigate = useNavigate();
  const { user, userProfile, logout } = useAuth();

  useEffect(() => {
    if (!user) {
      navigate("/welcome");
    }
  }, [user, navigate]);

  const handleLogout = async () => {
    try {
      await logout();
      navigate("/welcome");
    } catch (error) {
      console.error("Logout error:", error);
    }
  };

  const achievements = [
    { icon: Award, title: "Active Member", description: "Joined SAAN network" },
    {
      icon: Users,
      title: "Network Builder",
      description: `${userProfile?.connections?.length || 0} connections`,
    },
    { icon: BookOpen, title: "Learner", description: "Learning enthusiast" },
  ];

  const stats = [
    {
      label: "Connections",
      value: userProfile?.connections?.length?.toString() || "0",
    },
    { label: "Skills", value: userProfile?.skills?.length?.toString() || "0" },
    {
      label: "Interests",
      value: userProfile?.interests?.length?.toString() || "0",
    },
  ];

  if (!user || !userProfile) {
    return (
      <div className="min-h-screen bg-beige-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-rust-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-brown-500">Loading profile...</p>
        </div>
      </div>
    );
  }

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat("en", {
      year: "numeric",
      month: "long",
    }).format(date);
  };

  return (
    <div className="min-h-screen bg-beige-50 pb-20">
      {/* Header */}
      <div className="bg-white shadow-soft">
        <div className="px-4 py-6">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold text-brown-500">Profile</h1>
            <div className="flex items-center space-x-2">
              <Button variant="ghost" size="icon" className="text-brown-400">
                <Settings className="w-6 h-6" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={handleLogout}
                className="text-brown-400"
              >
                <LogOut className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="px-4 py-6">
        {/* Profile Header */}
        <Card className="p-6 shadow-soft mb-6">
          <div className="flex items-start space-x-4 mb-4">
            <Avatar className="w-20 h-20">
              <AvatarImage src={userProfile.photoURL || "/placeholder.svg"} />
              <AvatarFallback className="bg-rust-100 text-rust-600 text-xl">
                {userProfile.displayName?.charAt(0) || "U"}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <div className="flex items-center justify-between mb-2">
                <h2 className="text-xl font-bold text-brown-500">
                  {userProfile.displayName || "No name set"}
                </h2>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => navigate("/profile/edit")}
                  className="border-sand-200 text-brown-500"
                >
                  <Edit3 className="w-4 h-4 mr-2" />
                  Edit
                </Button>
              </div>
              <p className="text-brown-400 mb-2">
                {userProfile.currentRole && userProfile.company
                  ? `${userProfile.currentRole} at ${userProfile.company}`
                  : userProfile.currentRole || "Role not specified"}
              </p>
              {userProfile.location && (
                <div className="flex items-center text-brown-400 text-sm mb-2">
                  <MapPin className="w-4 h-4 mr-1" />
                  {userProfile.location}
                </div>
              )}
              <div className="flex items-center text-brown-400 text-sm">
                <Calendar className="w-4 h-4 mr-1" />
                Joined {formatDate(userProfile.createdAt)}
              </div>
            </div>
          </div>

          {userProfile.bio && (
            <p className="text-brown-400 text-sm mb-4">{userProfile.bio}</p>
          )}

          {/* Education & Professional Info */}
          {(userProfile.university || userProfile.fieldOfStudy) && (
            <div className="mb-4 p-3 bg-sand-50 rounded-lg">
              <h4 className="font-medium text-brown-500 mb-1">Education</h4>
              <p className="text-brown-400 text-sm">
                {userProfile.fieldOfStudy && userProfile.university
                  ? `${userProfile.fieldOfStudy} at ${userProfile.university}`
                  : userProfile.university || userProfile.fieldOfStudy}
                {userProfile.graduationYear &&
                  ` (${userProfile.graduationYear})`}
              </p>
            </div>
          )}

          {/* Skills */}
          {userProfile.skills && userProfile.skills.length > 0 && (
            <div className="mb-4">
              <h4 className="font-medium text-brown-500 mb-2">Skills</h4>
              <div className="flex flex-wrap gap-2">
                {userProfile.skills.slice(0, 6).map((skill) => (
                  <span
                    key={skill}
                    className="bg-sand-100 text-brown-600 px-2 py-1 rounded-full text-xs"
                  >
                    {skill}
                  </span>
                ))}
                {userProfile.skills.length > 6 && (
                  <span className="text-brown-400 text-xs">
                    +{userProfile.skills.length - 6} more
                  </span>
                )}
              </div>
            </div>
          )}

          {/* Stats */}
          <div className="grid grid-cols-3 gap-4 pt-4 border-t border-sand-200">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-xl font-bold text-rust-500">
                  {stat.value}
                </div>
                <div className="text-xs text-brown-400">{stat.label}</div>
              </div>
            ))}
          </div>
        </Card>

        {/* Achievements */}
        <div className="mb-6">
          <h3 className="text-lg font-semibold text-brown-500 mb-4">
            Achievements
          </h3>
          <div className="grid grid-cols-1 gap-3">
            {achievements.map((achievement, index) => {
              const Icon = achievement.icon;
              return (
                <Card key={index} className="p-4 shadow-soft">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-rust-100 rounded-lg flex items-center justify-center">
                      <Icon className="w-5 h-5 text-rust-500" />
                    </div>
                    <div>
                      <h4 className="font-medium text-brown-500">
                        {achievement.title}
                      </h4>
                      <p className="text-sm text-brown-400">
                        {achievement.description}
                      </p>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="space-y-3">
          <h3 className="text-lg font-semibold text-brown-500 mb-4">
            Quick Actions
          </h3>

          {[
            {
              icon: Users,
              title: "My Network",
              description: "View and manage connections",
            },
            {
              icon: BookOpen,
              title: "Learning Progress",
              description: "Track your courses",
            },
            {
              icon: Award,
              title: "Mentorship",
              description: "Mentor and mentee activities",
            },
            {
              icon: Globe,
              title: "Privacy Settings",
              description: "Control your visibility",
            },
          ].map((action, index) => {
            const Icon = action.icon;
            return (
              <Card
                key={index}
                className="p-4 shadow-soft hover:shadow-soft-lg transition-shadow cursor-pointer"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-sand-100 rounded-lg flex items-center justify-center">
                      <Icon className="w-5 h-5 text-olive-600" />
                    </div>
                    <div>
                      <h4 className="font-medium text-brown-500">
                        {action.title}
                      </h4>
                      <p className="text-sm text-brown-400">
                        {action.description}
                      </p>
                    </div>
                  </div>
                  <div className="w-6 h-6 text-brown-300">→</div>
                </div>
              </Card>
            );
          })}
        </div>
      </div>

      <BottomNavigation />
    </div>
  );
};

export default Profile;
