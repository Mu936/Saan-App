import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowRight, Users, Globe, Heart } from "lucide-react";
import { useNavigate } from "react-router-dom";

const Welcome = () => {
  const navigate = useNavigate();
  const [currentSlide, setCurrentSlide] = useState(0);

  const features = [
    {
      icon: <Users className="w-12 h-12 text-rust-500" />,
      title: "Connect & Network",
      description:
        "Build meaningful connections with fellow African alumni worldwide",
    },
    {
      icon: <Globe className="w-12 h-12 text-olive-500" />,
      title: "Discover Opportunities",
      description:
        "Access exclusive job opportunities and career advancement programs",
    },
    {
      icon: <Heart className="w-12 h-12 text-rust-500" />,
      title: "Give Back",
      description:
        "Mentor the next generation and contribute to African development",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-beige-50 to-sand-100 flex flex-col">
      {/* Header with Logo */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 py-12">
        <div className="text-center mb-8">
          {/* SAAN Logo */}
          <div className="w-24 h-24 mx-auto mb-6 rounded-2xl flex items-center justify-center shadow-african bg-white p-2">
            <img
              src="https://cdn.builder.io/api/v1/assets/64d6cc84666141fc9cf3668905b7aa5d/image-e2027a?format=webp&width=800"
              alt="SAAN Logo - Southern African Alumni Network"
              className="w-full h-full object-contain"
            />
          </div>

          <h1 className="text-4xl font-bold text-brown-500 mb-2">SAAN</h1>
          <p className="text-xl text-brown-400 font-medium mb-2">
            Southern African Alumni Network
          </p>
          <p className="text-lg text-brown-300 font-light">
            Connecting African Alumni to Opportunities
          </p>
        </div>

        {/* Feature Carousel */}
        <div className="w-full max-w-sm mb-8">
          <Card className="p-6 text-center min-h-[200px] flex flex-col justify-center shadow-soft">
            <div className="flex justify-center mb-4">
              {features[currentSlide].icon}
            </div>
            <h3 className="text-xl font-semibold text-brown-500 mb-2">
              {features[currentSlide].title}
            </h3>
            <p className="text-brown-400 leading-relaxed">
              {features[currentSlide].description}
            </p>
          </Card>

          {/* Dots Indicator */}
          <div className="flex justify-center space-x-2 mt-4">
            {features.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`w-2 h-2 rounded-full transition-colors ${
                  index === currentSlide ? "bg-rust-500" : "bg-sand-300"
                }`}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Bottom Action Buttons */}
      <div className="px-6 pb-8 pt-4">
        <div className="space-y-3">
          <Button
            onClick={() => navigate("/signup")}
            className="w-full bg-rust-500 hover:bg-rust-600 text-white py-4 text-lg font-medium rounded-xl shadow-soft"
          >
            Create Account
            <ArrowRight className="ml-2 w-5 h-5" />
          </Button>

          <Button
            onClick={() => navigate("/login")}
            variant="outline"
            className="w-full border-rust-200 text-rust-600 hover:bg-rust-50 py-4 text-lg font-medium rounded-xl"
          >
            I already have an account
          </Button>
        </div>

        <p className="text-center text-brown-300 text-sm mt-6">
          Join thousands of African alumni building the future together
        </p>
      </div>
    </div>
  );
};

export default Welcome;
